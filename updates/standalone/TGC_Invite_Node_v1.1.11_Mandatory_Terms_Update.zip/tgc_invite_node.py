#!/usr/bin/env python3
import hashlib
import json
import os
import queue
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import urllib.parse
import uuid
import zipfile
from datetime import datetime, timezone
import tkinter as tk
from tkinter import ttk, messagebox
from tgc_vrchat_multilog import MultiVRChatLogWatcher

APP_VERSION = "1.1.11"
HOTFIX_REVISION = 0
CLIENT_TYPE = "standalone"
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/Seawolf035/TGC-Node-Updates/main/manifest.json"
MAX_UPDATE_DOWNLOAD_BYTES = 100 * 1024 * 1024
USER_ID_RE = re.compile(r"\busr_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b")
JOIN_RE = re.compile(r"OnPlayerJoined\s+(.+?)\s+\((usr_[0-9a-fA-F-]{36})\)")
TIMESTAMP_RE = re.compile(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})")




# Integrated diagnostic: compatible with fixed-file legacy updaters.
#!/usr/bin/env python3
"""TGC Node v1.1.9 read-only, privacy-safe VRChat tracking report."""
import os
from pathlib import Path
import re
import time
from datetime import datetime

DIAG_JOIN_RE = re.compile(r"OnPlayerJoined\s+(.+?)\s+\((usr_[0-9a-fA-F-]{36})\)")
DIAG_LEAVE_RE = re.compile(r"OnPlayerLeft\s+(.+?)\s+\((usr_[0-9a-fA-F-]{36})\)")
DIAG_TAIL_BYTES = 12 * 1024 * 1024


def _diagnostic_inspect_log(path, now):
    stat = path.stat()
    size = stat.st_size
    item = dict(size=size, age_s=max(0, int(now - stat.st_mtime)),
                joins=0, joins_after_room=0, unmatched=0,
                leaves=0, transitions=0, truncated=size > DIAG_TAIL_BYTES)
    with path.open("rb") as f:
        if item["truncated"]:
            f.seek(-DIAG_TAIL_BYTES, os.SEEK_END)
            f.readline()
        lines = f.read().decode("utf-8", errors="replace").splitlines()
    latest_room = 0
    for i, line in enumerate(lines):
        if "Joining" in line and "Room" in line:
            latest_room = i
            item["transitions"] += 1
        if "OnPlayerJoined" in line:
            if DIAG_JOIN_RE.search(line):
                item["joins"] += 1
            else:
                item["unmatched"] += 1
        if DIAG_LEAVE_RE.search(line):
            item["leaves"] += 1
    item["joins_after_room"] = sum(bool(DIAG_JOIN_RE.search(line)) for line in lines[latest_room:])
    return item


def run_tracking_diagnostic(log_dir=None, output_dir=None, sample_seconds=10,
                            watcher_snapshot=None, session_stats=None):
    """Sample log files without stopping the live Node, then export counts only."""
    log_path = Path(log_dir) if log_dir else Path.home() / "AppData" / "LocalLow" / "VRChat" / "VRChat"
    destination = Path(output_dir) if output_dir else Path.home() / "Downloads"
    if not destination.is_dir():
        destination = Path.home()
    seconds = max(0, min(45, int(sample_seconds)))
    report = [
        "TGC Invite Node — VRChat Tracking Diagnostic",
        f'Generated: {datetime.now().astimezone().isoformat(timespec="seconds")}',
        "Read-only. Contains no player names, user IDs, log text, or Node credentials.",
        "This report is not uploaded automatically.",
        "",
        f"VRChat log directory found: {log_path.is_dir()}",
    ]
    if isinstance(watcher_snapshot, dict):
        report.extend([
            "Live watcher status:",
            f'  Running: {bool(watcher_snapshot.get("running"))}',
            f'  Active logs: {int(watcher_snapshot.get("active_logs") or 0)}',
            f'  Tracked logs: {int(watcher_snapshot.get("tracked_logs") or 0)}',
            f'  Tracked players: {int(watcher_snapshot.get("active_players") or 0)}',
        ])
    if isinstance(session_stats, dict):
        report.extend([
            "Current session (counts only):",
            f'  Seen: {int(session_stats.get("seen") or 0)}',
            f'  New: {int(session_stats.get("new") or 0)}',
            f'  Local duplicates: {int(session_stats.get("duplicates") or 0)}',
            f'  Pending uploads: {int(session_stats.get("pending") or 0)}',
        ])
    recent = []
    selected = []
    inspected = {}
    failures = 0
    if log_path.is_dir():
        try:
            logs = sorted(log_path.glob("output_log_*.txt"), key=lambda x: x.stat().st_mtime, reverse=True)
        except OSError as exc:
            logs = []
            failures += 1
            report.append(f"Cannot list VRChat logs: {type(exc).__name__}; details omitted.")
        report.append(f"Logs found: {len(logs)}")
        now = time.time()
        for path in logs:
            try:
                if now - path.stat().st_mtime <= 900:
                    recent.append(path)
            except OSError:
                failures += 1
        report.append(f"Logs modified within 15 minutes: {len(recent)}")
        selected = logs[:5]
        for i, path in enumerate(selected, 1):
            try:
                item = _diagnostic_inspect_log(path, now)
                inspected[path] = item
                report.extend([
                    f'Log #{i}: size {item["size"]} bytes; last modified {item["age_s"]}s ago',
                    f'  Recent enough: {item["age_s"] <= 900}',
                    f'  Recognized joins: {item["joins"]}; after last room: {item["joins_after_room"]}',
                    f'  Unrecognized join lines: {item["unmatched"]}; leaves: {item["leaves"]}',
                    f'  Room entries: {item["transitions"]}; tail limited to 12MiB: {item["truncated"]}',
                ])
            except (OSError, UnicodeError, ValueError) as exc:
                failures += 1
                report.append(f"Log #{i}: READ ERROR {type(exc).__name__}; details omitted.")
    if log_path.is_dir() and selected and seconds:
        report.append(f"Watching for appended logs for {seconds}s without pausing Node.")
        time.sleep(seconds)
    growth = 0
    new_joins = 0
    for i, path in enumerate(selected, 1):
        if path not in inspected:
            continue
        try:
            item = _diagnostic_inspect_log(path, time.time())
            previous = inspected[path]
            delta = max(0, item["size"] - previous["size"])
            join_delta = max(0, item["joins"] - previous["joins"])
            growth += delta
            new_joins += join_delta
            report.append(f"Log #{i} during sample: +{delta} bytes, +{join_delta} joins")
        except (OSError, UnicodeError, ValueError) as exc:
            failures += 1
            report.append(f"Log #{i}: SECOND READ ERROR {type(exc).__name__}; details omitted.")

    if not log_path.is_dir():
        diagnosis = "VRChat logs were not found for this Windows profile."
    elif failures:
        diagnosis = "Log access errors; check file permissions and access."
    elif not recent:
        diagnosis = "No recently updated VRChat logs; check running VRChat and Windows profile."
    elif any(item["unmatched"] for item in inspected.values()):
        diagnosis = "Unrecognized OnPlayerJoined lines; the watcher parser may need updating."
    elif not any(item["joins"] for item in inspected.values()):
        diagnosis = "No OnPlayerJoined entries detected; join a populated instance and try again."
    elif isinstance(watcher_snapshot, dict) and int(watcher_snapshot.get("active_players") or 0) == 0:
        diagnosis = "VRChat join entries found, but live watcher tracks zero players. Investigate watcher/callback."
    elif not growth:
        diagnosis = "Join entries present but no new log activity during sample."
    else:
        diagnosis = "VRChat log activity present; compare Seen/New counters for callback behavior."
    report.extend(["", f"Appended: {growth} bytes; new joins: {new_joins}",
                   f"DIAGNOSIS: {diagnosis}",
                   "This diagnostic does not alter tracking, queues, log files, or credentials."])
    output = destination / ("TGC_Node_Tracking_Diagnostic_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".txt")
    output.write_text("\n".join(report) + "\n", encoding="utf-8")
    return str(output), diagnosis


class _DATA_BLOB(__import__("ctypes").Structure):
    _fields_ = [
        ("cbData", __import__("ctypes").c_ulong),
        ("pbData", __import__("ctypes").POINTER(__import__("ctypes").c_char)),
    ]


def _dpapi_protect(raw: bytes, description="TGC Invite Node Key") -> bytes:
    if os.name != "nt":
        raise RuntimeError("Windows DPAPI is only available on Windows")
    import ctypes
    in_buffer = ctypes.create_string_buffer(raw)
    in_blob = _DATA_BLOB(len(raw), ctypes.cast(in_buffer, ctypes.POINTER(ctypes.c_char)))
    out_blob = _DATA_BLOB()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    ok = crypt32.CryptProtectData(
        ctypes.byref(in_blob), ctypes.c_wchar_p(description), None, None, None, 0,
        ctypes.byref(out_blob),
    )
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(out_blob.pbData)


def _dpapi_unprotect(blob: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("Windows DPAPI is only available on Windows")
    import ctypes
    in_buffer = ctypes.create_string_buffer(blob)
    in_blob = _DATA_BLOB(len(blob), ctypes.cast(in_buffer, ctypes.POINTER(ctypes.c_char)))
    out_blob = _DATA_BLOB()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    ok = crypt32.CryptUnprotectData(
        ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)
    )
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(out_blob.pbData)


class LocalStore:
    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()
        self._init()

    def _con(self):
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        return con

    def _init(self):
        with self._con() as con:
            con.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS sightings (
                    event_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    display_name TEXT,
                    seen_at TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_sightings_status ON sightings(status, created_at);
                CREATE TABLE IF NOT EXISTS recent_users (
                    user_id TEXT PRIMARY KEY,
                    last_seen_at TEXT NOT NULL
                );
                """
            )

    def add_sighting(self, user_id, display_name, seen_at, dedupe_minutes=60):
        now = datetime.now(timezone.utc)
        with self.lock, self._con() as con:
            row = con.execute("SELECT last_seen_at FROM recent_users WHERE user_id=?", (user_id,)).fetchone()
            if row:
                try:
                    last = datetime.fromisoformat(row["last_seen_at"].replace("Z", "+00:00"))
                    if (now - last).total_seconds() < max(0, dedupe_minutes) * 60:
                        con.execute("UPDATE recent_users SET last_seen_at=? WHERE user_id=?", (now.isoformat(), user_id))
                        return False, None
                except Exception:
                    pass
            event_id = "evt_" + uuid.uuid4().hex
            con.execute(
                "INSERT INTO sightings(event_id,user_id,display_name,seen_at,created_at,status) VALUES(?,?,?,?,?, 'pending')",
                (event_id, user_id, display_name, seen_at, now.isoformat()),
            )
            con.execute(
                "INSERT INTO recent_users(user_id,last_seen_at) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET last_seen_at=excluded.last_seen_at",
                (user_id, now.isoformat()),
            )
            return True, event_id

    def pending(self, limit=100):
        with self.lock, self._con() as con:
            rows = con.execute(
                "SELECT * FROM sightings WHERE status='pending' ORDER BY created_at ASC LIMIT ?", (int(limit),)
            ).fetchall()
            return [dict(r) for r in rows]

    def mark_submitted(self, event_ids):
        if not event_ids:
            return
        with self.lock, self._con() as con:
            con.executemany("UPDATE sightings SET status='submitted', last_error=NULL WHERE event_id=?", [(x,) for x in event_ids])

    def mark_attempt_error(self, event_ids, error):
        if not event_ids:
            return
        with self.lock, self._con() as con:
            con.executemany(
                "UPDATE sightings SET attempts=attempts+1, last_error=? WHERE event_id=?",
                [(str(error)[:1000], x) for x in event_ids],
            )

    def counts(self):
        with self.lock, self._con() as con:
            pending = con.execute("SELECT COUNT(*) FROM sightings WHERE status='pending'").fetchone()[0]
            submitted = con.execute("SELECT COUNT(*) FROM sightings WHERE status='submitted'").fetchone()[0]
            total = con.execute("SELECT COUNT(*) FROM sightings").fetchone()[0]
            return total, pending, submitted



# Shared template inserted into each desktop entrypoint by the release builder.
# Pure Python 3.8+; no external dependencies, no Relay call.
import getpass as _tgc_terms_getpass
import hashlib as _tgc_terms_hashlib
import json as _tgc_terms_json
import os as _tgc_terms_os
from pathlib import Path as _TgcTermsPath
from datetime import datetime as _TgcTermsDatetime, timezone as _TgcTermsTimezone
from tkinter import ttk as _tgc_terms_ttk, messagebox as _tgc_terms_messagebox
import tkinter as _tgc_terms_tk

TGC_DESKTOP_TERMS_VERSION = "2026-10-26.1"
TGC_DESKTOP_TERMS_TEXT = 'THE GAMER CLUB\nDESKTOP NODES AND STAFF LAUNCHER\nTERMS OF USE AND LIMITED SOFTWARE LICENSE\n\nAgreement version: 2026-10-26.1\nEffective date: October 26, 2026\nCreator: Seawolf (public creator name)\nCopyright © 2026 Seawolf for original material lawfully owned by Seawolf.\nThird-party materials remain owned and licensed by their respective rights holders.\n\nPLEASE READ THIS AGREEMENT BEFORE USING THE OFFICIAL SOFTWARE.\n\nThese terms govern the official TGC Standalone Invite Node, TGC Invite Node Plugin, TGC Staff Launcher, their embedded Nodes, updates, and the related The Gamer Club (TGC) invitation network services ("Desktop Software"). The Desktop Software is distinct from the TGC Staff Companion Android/Quest application, which has its own agreement. This agreement does not govern unrelated VRChat applications, third-party plugin hosts, or independent uses of third-party components under their own licenses.\n\nBy affirmatively selecting "I Agree" in the Desktop Software, you accept these terms for your own authorized use of the applicable TGC program. If you decline, close the terms window, or cannot load the agreement, the relevant TGC Node or Staff Launcher feature must not start or upload information. The host application of an optional Node plugin may continue operating without the TGC plugin.\n\n1. SCOPE AND PERMISSION\n\n1.1. Seawolf licenses original protectable TGC Desktop Software components only to the extent Seawolf has the legal authority to do so.\n1.2. Subject to this Agreement, applicable law, and any current TGC staff authorization, you receive a limited, personal, nonexclusive, nontransferable, revocable permission to install and operate official Desktop Software for approved TGC duties or testing.\n1.3. Agreement acceptance does not grant membership, staff rank, Node enrollment, moderation power, a Relay key, permission to operate central inviters, or rights to another person\'s VRChat credentials.\n1.4. TGC may limit or revoke access to TGC-controlled services as permitted by law and applicable policies.\n1.5. The permission is not a transfer of ownership and does not cover another party\'s intellectual property beyond rights given by that party.\n\n2. OWNERSHIP AND THIRD-PARTY COMPONENTS\n\n2.1. Seawolf retains the original rights Seawolf lawfully holds in original TGC source code, interface art, documentation, brand assets and other contributions.\n2.2. Other contributors and upstream projects retain their own intellectual-property rights. The Node Plugin integrates with a third-party VRChat automation host; it does not change that host\'s license or claim exclusive ownership of its code.\n2.3. Any applicable open-source license, hosting-service right, mandatory legal exception, right of interoperability, fair use or independently developed work is preserved. Public availability of a ZIP or repository does not automatically grant an unrestricted license to unrelated proprietary TGC components.\n2.4. TGC trademarks, staff badges, service access, names and verification identities may not be used to impersonate an official product or person.\n2.5. Nothing here grants ownership of VRChat, other users\' avatars, third-party tools, plugins, assets, data or services.\n\n3. OFFICIAL USE AND SECURITY\n\n3.1. Use only your own assigned TGC staff identity, accounts and deployment links. Do not transfer or disclose active Relay keys, private setup URLs, Windows DPAPI material, passwords, cookies or authentication tokens.\n3.2. Do not forge collected sightings, staff identities, account relationships, verification responses, invitation credits, remote commands or Relay events.\n3.3. Do not bypass revocation, an enrollment gate, required updates, rate limits, logging authorization or other TGC service access controls.\n3.4. A Node is a collector, not an official moderation system or independent authority to issue group invitations. It does not authorize its operator to scrape unrelated data, make unauthorized VRChat API requests, or bypass platform security.\n3.5. Report suspected leaked credentials, compromised devices, fake staff access or misuse to TGC management using the usual official staff channels.\n\n4. LOCAL LOG COLLECTION AND NETWORK DATA\n\n4.1. When voluntarily enabled and authorized, the Node reads relevant VRChat desktop output logs on your local machine and detects player-join observations.\n4.2. The Node may record VRChat user IDs, display names, observation timestamps, and local Node attribution; it may send selected sightings and related operational records to TGC\'s configured Relay for the invitation network. It does not need to transmit full output logs as part of normal collection.\n4.3. Observations can remain in the device\'s local retry queue while the internet or Relay is unavailable. Once uploaded, central TGC systems may store received observations and use them for authorized invite processing. A fixed central deletion/retention period is NOT promised by this Agreement.\n4.4. The operator must follow TGC privacy and staff rules and applicable law. Your acceptance is for your own operation of this tool; it does not purport to consent on behalf of other VRChat users whose activities are observed.\n4.5. The Software may send limited device/node status, staff attribution, version and verification information needed for network security and maintenance. It must not be used as a general-purpose surveillance service.\n4.6. Protect any data visible in staff dashboards, logs and local SQLite databases. Do not publish identifiable player histories, export stored identities for unrelated purposes, or distribute private group activity without authorization.\n\n5. PERMISSIONS, ACCOUNTS AND DEVICES\n\n5.1. The authorized TGC staff/Relay enrollment process remains separate from this license. A deployment link or valid token does not override these terms, and acceptance alone does not enroll a Node.\n5.2. You are responsible for keeping a Windows account and local TGC data directories reasonably secure and for using the tools only from systems you are permitted to operate.\n5.3. Acceptance is recorded locally for the current Windows user and applicable program type with the agreement version and content hash. The local record is not a VRChat credential or proof of continuing staff status.\n5.4. Each individual operator must affirmatively agree before using these official TGC features. Do not share an already-unlocked user session with someone else as a substitute for their own acceptance.\n5.5. On an amended agreement version, changed agreement content, new Windows user, or deleted/invalid acceptance record, the gate may require new affirmative acceptance.\n\n6. STAFF LAUNCHER AND OSC\n\n6.1. Staff Launcher provides limited authorized staff access to local VRChat instance management, optional OSC controls and an embedded Node.\n6.2. VRChat controls, OS processes, ports, microphone input, OSC chatbox changes and avatar scaling may be constrained by the operating system, the client, worlds, network conditions and third-party limits.\n6.3. Follow all TGC staff role policies, instance limits, age/safety rules and moderation procedures. Cosmetic features, a valid agreement or access to an OSC button do not grant moderation privilege.\n6.4. Do not use automated VRChat features to evade platform restrictions or interfere with other members.\n\n7. SOFTWARE AND UPDATE INTEGRITY\n\n7.1. Use the official TGC release sources and normal update channels. Validate update provenance and expected package integrity.\n7.2. Important software updates can be marked REQUIRED. When required, the supported installer may pause ordinary network activity until the official update is installed.\n7.3. Back up user-owned data before replacing program files. Keep local node configuration, DPAPI-protected keys, saved settings, SQLite queues, verification records, and other account-specific data. Do not copy another staff member\'s credentials.\n7.4. Local technical troubleshooting and authorized security testing remain allowed where permission or law provides it. Do not use test builds to impersonate official production releases.\n7.5. TGC may discontinue or change services, subject to any applicable legal obligations; continued compatibility with future VRChat or Windows releases is not guaranteed.\n\n8. THIRD-PARTY RULES\n\n8.1. You remain responsible for complying with VRChat\'s applicable Terms, Community Guidelines, API rules, and any separate terms governing Steam, Windows, Discord, GitHub and other integrated services.\n8.2. These TGC terms cannot confer permissions or exceptions prohibited by a third-party provider. Nothing here supersedes valid mandatory legal protections.\n\n9. SAFE OPERATION AND USER CONDUCT\n\n9.1. Use reasonable care to prevent account compromise, accidental disclosure, unauthorized deployments, misuse of personal data and disruption of TGC events.\n9.2. Do not access other people\'s private files, impersonate members, send unauthorized invitations or attempt to interfere with staff verification.\n9.3. Stop using the affected TGC network function if your authorization is revoked, a system explicitly requires a new version, or you discover an active compromise.\n\n10. SERVICE DISCLAIMERS\n\n10.1. To the extent permitted by applicable law, official Desktop Software is provided "AS IS" and "AS AVAILABLE" without guarantees of uninterrupted operation, fitness for a particular purpose or successful delivery of every log event.\n10.2. A local queue record or Relay acknowledgment is not proof that any invitation was sent or received.\n10.3. Connectivity, VRChat log output, Windows and antivirus rules, account access, API policies and third-party application changes may interrupt operation.\n\n11. LIABILITY\n\n11.1. To the extent applicable law permits, the rights holders are not responsible for indirect or consequential losses from interruption, third-party outages, user misconfiguration or unauthorized actions.\n11.2. Nothing excludes liability that cannot lawfully be excluded, restricts statutory protections that cannot be waived, or imposes an unlawful forfeiture of rights.\n\n12. TERMINATION AND DECLINING\n\n12.1. You may decline by selecting "Decline" or closing the agreement dialog. The TGC program should remain inactive until you later choose to agree.\n12.2. If TGC terminates your staff or Node authorization, this agreement does not override that revocation.\n12.3. Removing local acceptance is not the same as deleting enrolled keys, accounts or user data. Existing local operational records should remain available for authorized recovery and deletion procedures.\n\n13. CHANGES TO THESE TERMS\n\n13.1. A materially changed agreement must display its updated content and obtain a new affirmative acceptance before the affected TGC program resumes use.\n13.2. Merely visiting a repository, viewing source, downloading an archive, or using a third-party plugin host does not by itself constitute assent to this click-through Agreement.\n13.3. Acceptance evidence is stored locally, not automatically sent as a new personal-data event to the Relay.\n\n14. GOVERNING LAW AND SEVERABILITY\n\n14.1. Rights and obligations are subject to applicable law and mandatory protections. No mandatory right is waived by an overbroad clause.\n14.2. If one provision is invalid or unenforceable, the remaining lawful provisions continue to the extent permitted.\n14.3. This document does not invent an arbitration obligation, waive class-action rights, or select a jurisdiction without additional notice and agreement.\n\n15. QUESTIONS\n\n15.1. For authorization, operation or agreement questions, contact the appropriate TGC owner or designated staff administrator using the established TGC staff support channels.\n15.2. Do not include passwords, session cookies, private deployment links or other active secrets in routine support messages.\n\nBY CHECKING "I HAVE READ AND AGREE" AND PRESSING "I AGREE", YOU ACKNOWLEDGE THIS AGREEMENT AND AFFIRM YOUR OWN ACCEPTANCE FOR THE SELECTED TGC PROGRAM.\n'
TGC_DESKTOP_TERMS_SHA256 = _tgc_terms_hashlib.sha256(
    TGC_DESKTOP_TERMS_TEXT.encode("utf-8")
).hexdigest()
_TGC_TERMS_SCOPES = frozenset(("standalone", "plugin", "staff_launcher"))


def tgc_terms_record_path(scope):
    if scope not in _TGC_TERMS_SCOPES:
        raise ValueError("Unrecognized TGC terms scope.")
    # LOCALAPPDATA belongs to this Windows user; not the installation or Node key.
    # Per-scope evidence is independent for Node, plugin, and Staff Launcher.
    local = _tgc_terms_os.environ.get("LOCALAPPDATA")
    base = _TgcTermsPath(local) if local else _TgcTermsPath.home() / ".local" / "share"
    return base / "TheGamerClub" / "DesktopAgreements" / (scope + ".json")


def tgc_terms_accepted(scope):
    try:
        record = _tgc_terms_json.loads(
            tgc_terms_record_path(scope).read_text(encoding="utf-8")
        )
        return (
            isinstance(record, dict)
            and record.get("agreement_version") == TGC_DESKTOP_TERMS_VERSION
            and record.get("agreement_sha256") == TGC_DESKTOP_TERMS_SHA256
            and record.get("program") == scope
            and record.get("windows_user") == _tgc_terms_getpass.getuser()
            and bool(record.get("accepted_at_utc"))
        )
    except (OSError, ValueError, TypeError):
        return False


def tgc_terms_save_acceptance(scope):
    target = tgc_terms_record_path(scope)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "agreement_version": TGC_DESKTOP_TERMS_VERSION,
        "agreement_sha256": TGC_DESKTOP_TERMS_SHA256,
        "program": scope,
        "windows_user": _tgc_terms_getpass.getuser(),
        "accepted_at_utc": _TgcTermsDatetime.now(_TgcTermsTimezone.utc).isoformat(),
    }
    # Atomic commit so a cancelled or interrupted write never grants acceptance.
    import tempfile as _tgc_terms_tempfile
    with _tgc_terms_tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=str(target.parent), suffix=".tmp", delete=False
    ) as tmp:
        temp_name = tmp.name
        _tgc_terms_json.dump(payload, tmp, indent=2)
        tmp.write("\n")
        tmp.flush()
        _tgc_terms_os.fsync(tmp.fileno())
    try:
        _tgc_terms_os.replace(temp_name, target)
    finally:
        if _tgc_terms_os.path.exists(temp_name):
            _tgc_terms_os.remove(temp_name)
    if not tgc_terms_accepted(scope):
        raise RuntimeError("Could not verify saved agreement acceptance.")


def _tgc_terms_dialog(root, scope, required):
    if not isinstance(TGC_DESKTOP_TERMS_TEXT, str) or len(TGC_DESKTOP_TERMS_TEXT) < 2500:
        _tgc_terms_messagebox.showerror("TGC agreement error",
            "The agreement is missing or incomplete. TGC features cannot start.")
        return False
    dlg = _tgc_terms_tk.Toplevel(root)
    dlg.title("The Gamer Club - Terms of Use" if required else "TGC Terms of Use")
    dlg.geometry("800x610")
    dlg.minsize(600, 420)
    dlg.configure(bg="#142338")
    accepted = {"value": False}
    def decline():
        accepted["value"] = False
        dlg.destroy()
    dlg.protocol("WM_DELETE_WINDOW", decline)
    outer = _tgc_terms_ttk.Frame(dlg, padding=15)
    outer.pack(fill="both", expand=True)
    _tgc_terms_ttk.Label(
        outer, text="TGC Desktop Software Agreement", font=("Segoe UI", 17, "bold")
    ).pack(anchor="w", pady=(0, 5))
    _tgc_terms_ttk.Label(
        outer, text="Read the terms below before enabling this TGC program."
        if required else "Current terms for this TGC desktop program.",
        wraplength=730,
    ).pack(anchor="w", pady=(0, 8))
    area = _tgc_terms_ttk.Frame(outer)
    area.pack(fill="both", expand=True)
    scroller = _tgc_terms_ttk.Scrollbar(area, orient="vertical")
    readout = _tgc_terms_tk.Text(
        area, wrap="word", height=22, width=90,
        font=("Segoe UI", 10), padx=10, pady=10,
        yscrollcommand=scroller.set
    )
    scroller.configure(command=readout.yview)
    scroller.pack(side="right", fill="y")
    readout.pack(side="left", fill="both", expand=True)
    readout.insert("1.0", TGC_DESKTOP_TERMS_TEXT)
    readout.configure(state="disabled")
    if required:
        agreed = _tgc_terms_tk.BooleanVar(value=False)
        check = _tgc_terms_ttk.Checkbutton(
            outer, text="I have read and agree to the TGC Desktop Software Terms of Use",
            variable=agreed
        )
        check.pack(anchor="w", pady=(12, 7))
        _tgc_terms_ttk.Label(
            outer, text="Declining will leave this TGC software inactive. "
            "Your existing credentials, settings and queued sightings are preserved.",
            wraplength=710,
        ).pack(anchor="w", pady=(0, 5))
    buttons = _tgc_terms_ttk.Frame(outer)
    buttons.pack(fill="x", pady=(6, 0))
    _tgc_terms_ttk.Button(
        buttons, text="Decline" if required else "Close",
        command=decline
    ).pack(side="right", padx=(8, 0))
    if required:
        def affirm():
            if not agreed.get():
                _tgc_terms_messagebox.showwarning(
                    "Please confirm acceptance",
                    "You must check the agreement box before pressing I Agree.",
                    parent=dlg,
                )
                return
            try:
                tgc_terms_save_acceptance(scope)
            except Exception as exc:
                _tgc_terms_messagebox.showerror(
                    "Cannot save agreement",
                    "The agreement could not be saved. TGC features remain inactive.\n"
                    + str(exc), parent=dlg
                )
                return
            accepted["value"] = True
            dlg.destroy()
        _tgc_terms_ttk.Button(
            buttons, text="I Agree", command=affirm
        ).pack(side="right")
    dlg.lift()
    dlg.focus_force()
    dlg.grab_set()
    root.wait_window(dlg)
    return bool(accepted["value"] and tgc_terms_accepted(scope)) if required else False


def tgc_terms_require(root, scope):
    if tgc_terms_accepted(scope):
        return True
    return _tgc_terms_dialog(root, scope, required=True)


def tgc_terms_view(root):
    return _tgc_terms_dialog(root, "standalone", required=False)


class TGCInviteNode:
    def __init__(self, root):
        self.root = root
        self.root.title("TGC Invite Node")
        self.base = os.path.dirname(os.path.abspath(__file__))
        self.config_path = os.path.join(self.base, "node_config.json")
        self.key_path = os.path.join(self.base, "node_key.dpapi")
        self.store = LocalStore(os.path.join(self.base, "node_queue.db"))
        self.config = self._load_config()

        self.sync_stop = threading.Event()
        self.sync_thread = None
        self.sync_lock = threading.Lock()
        self.session_seen = 0
        self.session_new = 0
        self.session_duplicates = 0
        self.session_submitted = 0
        self.recent_messages = queue.Queue()
        self.release_info = {}
        self.update_required = False
        self.update_in_progress = False
        self.update_notice_shown_for = ""

        self.watcher = MultiVRChatLogWatcher(self._on_join, self._set_watcher_status)
        self._build_ui()
        self.root.after(500, self._refresh_ui)
        if self.config.get("relay_url") and self.config.get("node_id") and self.config.get("node_key_runtime"):
            self.root.after(1400, lambda: self.check_for_updates(silent=True))

    def _default_config(self):
        return {
            "relay_url": "",
            "node_id": "",
            "node_name": "",
            "install_id": "",
            "sync_interval_seconds": 60,
            "batch_size": 100,
            "local_dedupe_minutes": 60,
            "auto_start": True,
            "ignore_user_ids": [],
        }

    def _load_protected_key(self):
        if not os.path.isfile(self.key_path):
            return ""
        try:
            with open(self.key_path, "rb") as f:
                protected = f.read()
            if not protected:
                return ""
            return _dpapi_unprotect(protected).decode("utf-8")
        except Exception:
            return ""

    def _save_protected_key(self, value):
        value = str(value or "")
        if not value:
            try:
                if os.path.exists(self.key_path):
                    os.remove(self.key_path)
            except OSError:
                pass
            return
        protected = _dpapi_protect(value.encode("utf-8"))
        tmp = self.key_path + ".tmp"
        with open(tmp, "wb") as f:
            f.write(protected)
        os.replace(tmp, self.key_path)

    def _load_config(self):
        data = self._default_config()
        legacy_key = ""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                if isinstance(loaded, dict):
                    legacy_key = str(loaded.pop("node_key", "") or "")
                    loaded.pop("node_key_runtime", None)
                    data.update(loaded)
        except Exception:
            pass
        if not str(data.get("install_id") or "").strip():
            data["install_id"] = uuid.uuid4().hex
        protected_key = self._load_protected_key()
        data["node_key_runtime"] = protected_key or legacy_key
        if legacy_key and not protected_key and os.name == "nt":
            try:
                self._save_protected_key(legacy_key)
                payload = dict(data)
                payload.pop("node_key_runtime", None)
                with open(self.config_path, "w", encoding="utf-8") as f:
                    json.dump(payload, f, indent=2)
            except Exception:
                pass
        return data

    def _save_config(self):
        payload = dict(self.config)
        raw_key = str(payload.pop("node_key_runtime", "") or "")
        payload.pop("node_key", None)
        tmp = self.config_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        os.replace(tmp, self.config_path)
        self._save_protected_key(raw_key)

    def _build_ui(self):
        frame = ttk.Frame(self.root)
        frame.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)
        ttk.Button(frame, text="View Terms of Use",
            command=lambda: tgc_terms_view(self.root)).pack(anchor=tk.W)
        ttk.Label(frame, text="The Gamer Club — Invite Node", font=("Segoe UI", 16, "bold")).pack(anchor=tk.W)
        ttk.Label(
            frame,
            text="Watches every active VRChat instance on this PC and reports encountered user IDs to the TGC Google relay. This node contains no VRChat login credentials.",
            wraplength=760,
        ).pack(anchor=tk.W, pady=(2, 10))

        deploy = ttk.LabelFrame(frame, text="Quick Deployment")
        deploy.pack(fill=tk.X, pady=(0, 10))
        deploy.columnconfigure(0, weight=1)
        ttk.Label(
            deploy,
            text="Paste the one-time TGC deployment link from an owner. It contains the relay address, so there is no Node ID, Node Key, or Apps Script URL to type manually.",
            wraplength=760,
            justify=tk.LEFT,
        ).grid(row=0, column=0, columnspan=2, sticky=tk.W, padx=6, pady=(5, 3))
        self.deploy_var = tk.StringVar()
        ttk.Entry(deploy, textvariable=self.deploy_var).grid(row=1, column=0, sticky=tk.EW, padx=6, pady=(3, 6))
        ttk.Button(deploy, text="Deploy This Node", command=self.redeem_deployment).grid(row=1, column=1, sticky=tk.E, padx=6, pady=(3, 6))

        settings = ttk.LabelFrame(frame, text="Node Preferences")
        settings.pack(fill=tk.X, pady=(0, 10))
        settings.columnconfigure(1, weight=1)
        self.url_var = tk.StringVar(value=self.config.get("relay_url", ""))
        self.node_id_var = tk.StringVar(value=self.config.get("node_id", ""))
        self.key_var = tk.StringVar(value=self.config.get("node_key_runtime", ""))
        self.name_var = tk.StringVar(value=self.config.get("node_name", ""))
        self.interval_var = tk.IntVar(value=int(self.config.get("sync_interval_seconds", 60)))
        self.dedupe_var = tk.IntVar(value=int(self.config.get("local_dedupe_minutes", 60)))

        ttk.Label(settings, text="Node:").grid(row=0, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings, textvariable=self.name_var).grid(row=0, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings, text="Enrollment is managed exclusively through Quick Deployment.", wraplength=690).grid(row=1, column=0, columnspan=4, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings, text="Sync Interval:").grid(row=4, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Spinbox(settings, from_=15, to=3600, increment=15, textvariable=self.interval_var).grid(row=4, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings, text="seconds").grid(row=4, column=2, sticky=tk.W)
        ttk.Label(settings, text="Local Repeat Dedupe:").grid(row=5, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Spinbox(settings, from_=0, to=10080, textvariable=self.dedupe_var).grid(row=5, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings, text="minutes").grid(row=5, column=2, sticky=tk.W)
        btns = ttk.Frame(settings)
        btns.grid(row=6, column=0, columnspan=4, sticky=tk.W, padx=6, pady=6)
        ttk.Button(btns, text="Save", command=self.save_from_ui).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btns, text="Test Relay", command=self.test_relay).pack(side=tk.LEFT, padx=5)
        ttk.Button(btns, text="Sync Now", command=self.sync_now).pack(side=tk.LEFT, padx=5)

        updates = ttk.LabelFrame(frame, text="Node Updates")
        updates.pack(fill=tk.X, pady=(0, 10))
        updates.columnconfigure(0, weight=1)
        self.update_status_var = tk.StringVar(value=f"Installed: v{APP_VERSION} — update status not checked")
        ttk.Label(
            updates,
            textvariable=self.update_status_var,
            wraplength=690,
            justify=tk.LEFT,
        ).grid(row=0, column=0, sticky=tk.W, padx=6, pady=5)
        update_buttons = ttk.Frame(updates)
        update_buttons.grid(row=0, column=1, sticky=tk.E, padx=6, pady=5)
        ttk.Button(
            update_buttons,
            text="Check for Updates",
            command=self.check_for_updates,
        ).pack(side=tk.LEFT, padx=(0, 5))
        self.install_update_btn = ttk.Button(
            update_buttons,
            text="Install Update",
            command=self.install_update,
            state=tk.DISABLED,
        )
        self.install_update_btn.pack(side=tk.LEFT)

        status = ttk.LabelFrame(frame, text="Status")
        status.pack(fill=tk.X, pady=(0, 10))
        self.watcher_status_var = tk.StringVar(value="Stopped")
        self.instances_var = tk.StringVar(value="0")
        self.players_var = tk.StringVar(value="0")
        self.relay_status_var = tk.StringVar(value="Not tested")
        self.count_var = tk.StringVar(value="")
        ttk.Label(status, text="VRChat Logs:").grid(row=0, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, textvariable=self.watcher_status_var).grid(row=0, column=1, columnspan=3, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, text="Active Instances:").grid(row=1, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, textvariable=self.instances_var, font=("Segoe UI", 10, "bold")).grid(row=1, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, text="Tracked Players:").grid(row=1, column=2, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, textvariable=self.players_var, font=("Segoe UI", 10, "bold")).grid(row=1, column=3, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, text="Relay:").grid(row=2, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, textvariable=self.relay_status_var).grid(row=2, column=1, columnspan=3, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, text="Session:").grid(row=3, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, textvariable=self.count_var).grid(row=3, column=1, columnspan=3, sticky=tk.W, padx=6, pady=4)

        actions = ttk.Frame(frame)
        actions.pack(fill=tk.X, pady=(0, 10))
        self.start_btn = ttk.Button(actions, text="Start Node", command=self.start)
        self.start_btn.pack(side=tk.LEFT, padx=(0, 6))
        self.stop_btn = ttk.Button(actions, text="Stop", command=self.stop, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=6)
        self.diagnostic_btn = ttk.Button(actions, text="Diagnose Tracking", command=self.diagnose_tracking)
        self.diagnostic_btn.pack(side=tk.LEFT, padx=6)

        recent_frame = ttk.LabelFrame(frame, text="Recent Sightings")
        recent_frame.pack(fill=tk.BOTH, expand=True)
        self.recent = tk.Text(recent_frame, height=12, wrap=tk.WORD, state=tk.DISABLED)
        self.recent.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)

        self.root.protocol("WM_DELETE_WINDOW", self.close)
        if self.config.get("auto_start"):
            self.root.after(700, self.start)

    def diagnose_tracking(self):
        """Run the built-in privacy-safe diagnostic without blocking the window."""
        self.diagnostic_btn.config(state=tk.DISABLED)
        self._log_recent("Tracking diagnostic started (10-second sample)")
        snapshot = self.watcher.snapshot()
        _total, pending, _submitted = self.store.counts()
        stats = dict(seen=self.session_seen, new=self.session_new,
                     duplicates=self.session_duplicates, pending=pending)

        def worker():
            try:
                report, diagnosis = run_tracking_diagnostic(
                    log_dir=self.watcher.log_dir,
                    output_dir=os.path.join(os.path.expanduser("~"), "Downloads"),
                    sample_seconds=10, watcher_snapshot=snapshot, session_stats=stats)
            except Exception as error:
                error_type = type(error).__name__
                def failed():
                    self.diagnostic_btn.config(state=tk.NORMAL)
                    self._log_recent("Tracking diagnostic failed")
                    messagebox.showerror("Tracking Diagnostic",
                                         f"Could not generate report: {error_type}")
                self.root.after(0, failed)
                return

            def completed():
                self.diagnostic_btn.config(state=tk.NORMAL)
                self._log_recent("Tracking diagnostic complete — report saved")
                if messagebox.askyesno(
                    "Tracking Diagnostic",
                    f"{diagnosis}\n\nReport saved to:\n{report}\n\nOpen report now?"
                ):
                    try:
                        os.startfile(report)
                    except (AttributeError, OSError):
                        pass
            self.root.after(0, completed)

        threading.Thread(target=worker, daemon=True,
                         name="NodeTrackingDiagnostic").start()

    def save_from_ui(self):
        self.config.update({
            "sync_interval_seconds": max(15, int(self.interval_var.get())),
            "local_dedupe_minutes": max(0, int(self.dedupe_var.get())),
        })
        self._save_config()
        messagebox.showinfo("TGC Invite Node", "Configuration saved.")

    def _set_watcher_status(self, summary):
        if isinstance(summary, dict):
            active = bool(summary.get("logging_warning"))
            if active != getattr(self, "_last_logging_warning", False):
                self._last_logging_warning = active
                self._log_recent('WARNING: VRChat logging appears disabled (no recent log data). Enable VRChat output logging in VRChat settings and restart VRChat.' if active else
                                 "VRChat logging resumed; warning cleared.")
        if isinstance(summary, dict):
            self.root.after(0, self.watcher_status_var.set, summary.get("message", "Watching VRChat logs"))
            self.root.after(0, self.instances_var.set, str(summary.get("active_logs", 0)))
            self.root.after(0, self.players_var.set, str(summary.get("active_players", 0)))
        else:
            self.root.after(0, self.watcher_status_var.set, str(summary))

    def _log_recent(self, msg):
        self.recent_messages.put(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

    def _on_join(self, user_id, display_name, seen_at, source_log=None):
        self.session_seen += 1
        if user_id in set(self.config.get("ignore_user_ids") or []):
            return
        added, _ = self.store.add_sighting(
            user_id, display_name, seen_at, int(self.config.get("local_dedupe_minutes", 60))
        )
        if added:
            self.session_new += 1
            source = os.path.basename(source_log) if source_log else "VRChat"
            self._log_recent(f"Queued: {display_name} ({user_id}) — {source}")
        else:
            self.session_duplicates += 1
            self._log_recent(f"Local duplicate: {display_name}")

    def _post_to_url(self, url, payload, timeout=25):
        if not tgc_terms_accepted("standalone"):
            raise PermissionError("TGC Terms of Use not accepted.")
        url = str(url or "").strip()
        if not url.lower().startswith("https://"):
            raise RuntimeError("Relay URL is missing or invalid")
        raw = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=raw,
            headers={"Content-Type": "application/json", "User-Agent": f"TGC-Invite-Node/{APP_VERSION}"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode("utf-8", errors="replace"))
        if not result.get("ok"):
            raise RuntimeError(result.get("error") or "Relay rejected request")
        return result

    def _parse_deployment_input(self, value):
        value = str(value or "").strip()
        if not value:
            raise RuntimeError("Paste the deployment link or code from a TGC owner")
        relay_url = str(self.config.get("relay_url") or "").strip()
        code = value.upper()
        if value.lower().startswith("https://"):
            parsed = urllib.parse.urlsplit(value)
            query = urllib.parse.parse_qs(parsed.query)
            code = str((query.get("deploy") or [""])[0]).strip().upper()
            relay_url = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, "", ""))
        if not re.fullmatch(r"TGC-DEPLOY(?:-[A-F0-9]{4}){5}", code):
            raise RuntimeError("That is not a valid TGC deployment code/link")
        if not relay_url.lower().startswith("https://"):
            raise RuntimeError("This fresh install needs the full deployment link, not only the short code")
        return relay_url, code

    def redeem_deployment(self):
        if not tgc_terms_accepted("standalone"):
            raise PermissionError("TGC Terms of Use not accepted.")
        try:
            relay_url, code = self._parse_deployment_input(self.deploy_var.get())
        except Exception as error:
            messagebox.showerror("Deploy TGC Invite Node", str(error))
            return
        install_id = str(self.config.get("install_id") or "").strip() or uuid.uuid4().hex
        self.config["install_id"] = install_id
        try:
            self._save_config()
        except Exception:
            pass
        self.relay_status_var.set("Redeeming one-time deployment code…")

        def worker():
            try:
                data = self._post_to_url(
                    relay_url,
                    {
                        "action": "redeem_deployment",
                        "code": code,
                        "client_type": CLIENT_TYPE,
                        "version": APP_VERSION,
                        "install_id": install_id,
                    },
                    timeout=30,
                )
                node_id = str(data.get("node_id") or "").strip()
                node_key = str(data.get("node_key") or "").strip()
                node_name = str(data.get("node_name") or "").strip()
                discord_id = str(data.get("discord_id") or "").strip()
                if not node_id or not node_key:
                    raise RuntimeError("Relay did not return complete node credentials")
                self.config.update({
                    "relay_url": relay_url,
                    "node_id": node_id,
                    "node_key_runtime": node_key,
                    "node_name": node_name,
                    "auto_start": True,
                })
                self._save_config()

                def finish():
                    self.url_var.set(relay_url)
                    self.node_id_var.set(node_id)
                    self.key_var.set(node_key)
                    self.name_var.set(node_name)
                    self.deploy_var.set("")
                    self.root.title(f"TGC Invite Node — {node_name}" if node_name else "TGC Invite Node")
                    self.relay_status_var.set(f"Deployed and verified — {node_name or node_id}")
                    messagebox.showinfo(
                        "TGC Invite Node Deployed",
                        "Deployment complete.\n\n"
                        f"Node: {node_name or node_id}\n"
                        + (f"Staff Discord ID: {discord_id}\n" if discord_id else "")
                        + "\nThe permanent Node Key is protected with Windows DPAPI. The node will now start automatically.",
                    )
                    self.start()
                    self.check_for_updates(silent=True)
                self.root.after(0, finish)
            except Exception as error:
                self.root.after(0, self.relay_status_var.set, f"Deployment failed: {error}")
                self.root.after(0, lambda err=error: messagebox.showerror("Deploy TGC Invite Node", str(err)))

        threading.Thread(target=worker, daemon=True, name="NodeDeployment").start()

    def _post(self, payload, timeout=25):
        if not tgc_terms_accepted("standalone"):
            raise PermissionError("TGC Terms of Use not accepted.")
        url = self.config.get("relay_url", "").strip()
        if not url:
            raise RuntimeError("Relay URL is not configured")
        return self._post_to_url(url, payload, timeout=timeout)

    def _auth_payload(self, action, **extra):
        node_id = self.config.get("node_id", "").strip()
        node_key = self.config.get("node_key_runtime", "").strip()
        if not node_id or not node_key:
            raise RuntimeError("Node ID / Node Key are not configured")
        # The relay/Apps Script is authoritative for the node's display name.
        # Do not send a local node_name back, otherwise touchNode_() would be
        # allowed to overwrite the name assigned centrally in the Nodes sheet.
        payload = {
            "action": action,
            "node_id": node_id,
            "node_key": node_key,
            "version": APP_VERSION,
            "client_type": CLIENT_TYPE,
        }
        payload.update(extra)
        return payload

    def _apply_relay_identity(self, data):
        canonical_name = str((data or {}).get("node_name") or "").strip()
        if not canonical_name:
            return
        self.config["node_name"] = canonical_name
        try:
            self._save_config()
        except Exception:
            pass

        def apply_ui():
            self.name_var.set(canonical_name)
            self.root.title(f"TGC Invite Node — {canonical_name}")

        self.root.after(0, apply_ui)

    def _refresh_relay_identity(self, update_status=True):
        try:
            data = self._post(self._auth_payload("node_status"))
            self._apply_relay_identity(data)
            canonical_name = str(data.get("node_name") or "").strip()
            if update_status:
                label = canonical_name or self.config.get("node_id", "")
                self.root.after(0, self.relay_status_var.set, f"Connected — {label}")
            return data
        except Exception as e:
            if update_status:
                self.root.after(0, self.relay_status_var.set, f"Error: {e}")
            return None

    @staticmethod
    def _version_tuple(value):
        text = str(value or "").strip().lower().replace("-plugin", "")
        match = re.search(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?", text)
        if not match:
            return (0, 0, 0)
        return tuple(int(part or 0) for part in match.groups())

    def _fetch_github_release(self):
        request = urllib.request.Request(
            UPDATE_MANIFEST_URL,
            headers={
                "Accept": "application/json",
                "Cache-Control": "no-cache",
                "User-Agent": f"TGC-Invite-Node-Updater/{APP_VERSION}",
            },
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            raw = response.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise RuntimeError("GitHub update manifest returned invalid JSON.")
        releases = data.get("releases") or {}
        release = releases.get(CLIENT_TYPE) if isinstance(releases, dict) else None
        if not isinstance(release, dict):
            raise RuntimeError("GitHub update manifest has no standalone release entry.")
        return release

    def _release_available(self, info):
        if not isinstance(info, dict):
            return False
        version = str(info.get("version") or "").strip()
        if not version:
            return False
        remote = self._version_tuple(version)
        installed = self._version_tuple(APP_VERSION)
        if remote != installed:
            return remote > installed
        try:
            return int(info.get("hotfix_revision") or 0) > HOTFIX_REVISION
        except (TypeError, ValueError):
            return False

    def _apply_release_info(self, release):
        if not isinstance(release, dict):
            return
        channel = str(release.get("channel") or CLIENT_TYPE).strip().lower()
        if channel and channel != CLIENT_TYPE:
            return
        version = str(release.get("version") or "").strip()
        if not version:
            return
        info = dict(release)
        info["version"] = version
        info["policy"] = str(info.get("policy") or "optional").strip().lower()
        self.release_info = info
        available = self._release_available(info)
        self.update_required = available and info["policy"] == "required"

        def apply_ui():
            if available:
                policy = info["policy"].capitalize()
                self.update_status_var.set(
                    f"Update available: v{version} — {policy}"
                    + (f" — {str(info.get('notes') or '').strip()}" if info.get("notes") else "")
                )
                self.install_update_btn.config(state=tk.NORMAL if not self.update_in_progress else tk.DISABLED)
                update_id = f"{version}:hotfix{info.get('hotfix_revision', 0)}"
                if info["policy"] in {"recommended", "required"} and self.update_notice_shown_for != update_id:
                    self.update_notice_shown_for = update_id
                    detail = (
                        f"TGC Invite Node v{version} is {info['policy']}.\n\n"
                        + (str(info.get("notes") or "").strip() + "\n\n" if info.get("notes") else "")
                    )
                    if info["policy"] == "required":
                        detail += "Sightings will continue to be buffered locally, but relay uploads are paused until you update."
                    else:
                        detail += "Please install the update when practical."
                    messagebox.showwarning("TGC Invite Node Update", detail)
            else:
                self.update_status_var.set(f"Installed: v{APP_VERSION} — current")
                self.install_update_btn.config(state=tk.DISABLED)
        self.root.after(0, apply_ui)

    def check_for_updates(self, silent=False):
        try:
            self.save_from_ui_silent()
        except Exception as error:
            if not silent:
                messagebox.showerror("TGC Invite Node", str(error))
            return

        def worker():
            try:
                release = self._fetch_github_release()
                self._apply_release_info(release)
                if not silent and not self._release_available(release):
                    self.root.after(0, lambda: messagebox.showinfo("TGC Invite Node", f"This node is current (v{APP_VERSION})."))
            except Exception as error:
                self.root.after(0, self.update_status_var.set, f"GitHub update check failed: {error}")
                if not silent:
                    self.root.after(0, lambda err=error: messagebox.showerror("TGC Invite Node", f"Could not check GitHub for updates:\n\n{err}"))

        threading.Thread(target=worker, daemon=True, name="NodeUpdateCheck").start()

    @staticmethod
    def _safe_zip_members(zf):
        members = []
        for info in zf.infolist():
            name = info.filename.replace("\\", "/")
            if not name or name.endswith("/"):
                continue
            if name.startswith("/") or ".." in name.split("/"):
                raise RuntimeError(f"Unsafe path in update package: {name}")
            members.append((info, name))
        return members

    def _download_and_stage_update(self, info):
        version = str(info.get("version") or "").strip()
        url = str(info.get("url") or "").strip()
        expected_hash = str(info.get("sha256") or "").strip().lower()
        if not version or not url or not expected_hash:
            raise RuntimeError("The GitHub release metadata is incomplete.")
        if not url.lower().startswith("https://"):
            raise RuntimeError("Update downloads must use HTTPS.")
        if not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
            raise RuntimeError("The GitHub release SHA-256 is invalid.")

        updates_dir = os.path.join(self.base, "updates")
        os.makedirs(updates_dir, exist_ok=True)
        temp_zip = os.path.join(updates_dir, f"node_update_{version}.zip.part")
        digest = hashlib.sha256()
        downloaded = 0
        req = urllib.request.Request(url, headers={"User-Agent": f"TGC-Invite-Node-Updater/{APP_VERSION}"})
        with urllib.request.urlopen(req, timeout=60) as response, open(temp_zip, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                downloaded += len(chunk)
                if downloaded > MAX_UPDATE_DOWNLOAD_BYTES:
                    raise RuntimeError("Update package is unexpectedly large.")
                digest.update(chunk)
                output.write(chunk)
        actual_hash = digest.hexdigest().lower()
        if actual_hash != expected_hash:
            try:
                os.remove(temp_zip)
            except OSError:
                pass
            raise RuntimeError("Update checksum verification failed. The package was not installed.")

        staging = tempfile.mkdtemp(prefix="tgc_node_update_", dir=updates_dir)
        with zipfile.ZipFile(temp_zip, "r") as zf:
            members = self._safe_zip_members(zf)
            names = [name for _, name in members]
            prefixes = {name.split("/", 1)[0] for name in names if "/" in name}
            root_prefix = ""
            if "tgc_invite_node.py" not in names and len(prefixes) == 1:
                candidate = next(iter(prefixes)) + "/"
                if candidate + "tgc_invite_node.py" in names:
                    root_prefix = candidate
            allowed = {
                "tgc_invite_node.py", "tgc_vrchat_multilog.py", "tgc_node_diagnostics.py", "tgc_node_update_helper.py",
                "run_node.bat", "check_python_setup.bat", "build_node_exe.bat",
                "README_NODE.txt", "START_HERE.txt", "node_config.example.json",
            }
            selected = []
            for info_obj, name in members:
                rel = name[len(root_prefix):] if root_prefix and name.startswith(root_prefix) else name
                if rel in allowed:
                    dst = os.path.join(staging, rel)
                    os.makedirs(os.path.dirname(dst) or staging, exist_ok=True)
                    with zf.open(info_obj) as src, open(dst, "wb") as out:
                        shutil.copyfileobj(src, out)
                    selected.append(rel)
        try:
            os.remove(temp_zip)
        except OSError:
            pass
        if "tgc_invite_node.py" not in selected or "tgc_vrchat_multilog.py" not in selected:
            shutil.rmtree(staging, ignore_errors=True)
            raise RuntimeError("Update ZIP does not contain the standalone node program files.")
        with open(os.path.join(staging, "update_manifest.json"), "w", encoding="utf-8") as fh:
            json.dump({"version": version, "files": selected}, fh, indent=2)
        return staging

    def install_update(self):
        info = dict(self.release_info or {})
        version = str(info.get("version") or "").strip()
        if not self._release_available(info):
            messagebox.showinfo("TGC Invite Node", "No newer update is currently available.")
            return
        policy = str(info.get("policy") or "optional").capitalize()
        notes = str(info.get("notes") or "").strip()
        prompt = f"Install TGC Invite Node v{version}?\n\nPolicy: {policy}"
        if notes:
            prompt += f"\n\n{notes}"
        prompt += "\n\nThe node will close, install the verified update, and restart automatically. Your Node ID, Node Key, settings, and queue database are preserved."
        if not messagebox.askyesno("Install Node Update", prompt):
            return
        if self.update_in_progress:
            return
        self.update_in_progress = True
        self.install_update_btn.config(state=tk.DISABLED)
        self.update_status_var.set(f"Downloading v{version}…")

        def worker():
            try:
                staging = self._download_and_stage_update(info)
                helper = os.path.join(self.base, "tgc_node_update_helper.py")
                if not os.path.isfile(helper):
                    helper_src = os.path.join(staging, "tgc_node_update_helper.py")
                    if os.path.isfile(helper_src):
                        shutil.copy2(helper_src, helper)
                if not os.path.isfile(helper):
                    raise RuntimeError("Updater helper is missing from this installation/update package.")
                subprocess.Popen(
                    [sys.executable, helper, "--pid", str(os.getpid()), "--base", self.base, "--staging", staging, "--version", version],
                    cwd=self.base,
                )
                self.root.after(0, self.update_status_var.set, f"Installing v{version} — restarting…")
                self.root.after(500, self._shutdown_for_update)
            except Exception as error:
                self.update_in_progress = False
                self.root.after(0, self.install_update_btn.config, {"state": tk.NORMAL})
                self.root.after(0, self.update_status_var.set, f"Update failed: {error}")
                self.root.after(0, lambda err=error: messagebox.showerror("Node Update Failed", str(err)))

        threading.Thread(target=worker, daemon=True, name="NodeUpdater").start()

    def _shutdown_for_update(self):
        try:
            self.stop()
            self.save_from_ui_silent()
        finally:
            self.root.destroy()

    def test_relay(self):
        self.save_from_ui_silent()
        threading.Thread(
            target=self._refresh_relay_identity,
            kwargs={"update_status": True},
            daemon=True,
        ).start()

    def generate_discord_link_code(self):
        self.save_from_ui_silent()

        def worker():
            try:
                data = self._post(self._auth_payload("create_node_link_code"))
                self._apply_relay_identity(data)
                code = str(data.get("code") or "").strip()
                expires_at = str(data.get("expires_at") or "").strip()
                node_name = str(data.get("node_name") or self.config.get("node_name") or "this node")
                if not code:
                    raise RuntimeError("Relay did not return a Discord link code")

                def show_code():
                    try:
                        self.root.clipboard_clear()
                        self.root.clipboard_append(code)
                        self.root.update_idletasks()
                    except Exception:
                        pass
                    self.relay_status_var.set(f"Discord link code ready — {code}")
                    messagebox.showinfo(
                        "Link Node to Discord",
                        (
                            f"Node: {node_name}\n\n"
                            f"Your one-time Discord link code is:\n\n{code}\n\n"
                            "The code has been copied to your clipboard.\n"
                            "In the TGC Discord, run:\n"
                            f"/verifynode code:{code}\n\n"
                            "This code expires in 10 minutes and can only be used once."
                            + (f"\nExpires: {expires_at}" if expires_at else "")
                        ),
                    )

                self.root.after(0, show_code)
            except Exception as error:
                self.root.after(0, self.relay_status_var.set, f"Link error: {error}")
                self.root.after(
                    0,
                    lambda err=error: messagebox.showerror(
                        "Link Node to Discord",
                        str(err),
                    ),
                )

        threading.Thread(
            target=worker,
            daemon=True,
            name="NodeDiscordLinkCode",
        ).start()

    def save_from_ui_silent(self):
        self.config.update({
            "sync_interval_seconds": max(15, int(self.interval_var.get())),
            "local_dedupe_minutes": max(0, int(self.dedupe_var.get())),
        })
        self._save_config()

    def sync_now(self):
        self.save_from_ui_silent()
        threading.Thread(target=self._sync_once, daemon=True).start()

    def _sync_once(self):
        if not tgc_terms_accepted("standalone"):
            return
        if self.update_required:
            self.root.after(0, self.relay_status_var.set, "Required update — sightings are being buffered locally")
            return 0
        if not self.sync_lock.acquire(blocking=False):
            return 0
        try:
            batch = self.store.pending(int(self.config.get("batch_size", 100)))
            if not batch:
                self.root.after(0, self.relay_status_var.set, "Connected — nothing queued")
                return 0
            sightings = [
                {
                    "event_id": r["event_id"],
                    "user_id": r["user_id"],
                    "display_name": r.get("display_name") or r["user_id"],
                    "seen_at": r["seen_at"],
                }
                for r in batch
            ]
            ids = [r["event_id"] for r in batch]
            try:
                result = self._post(self._auth_payload("submit_sightings", sightings=sightings))
                accepted = result.get("accepted_event_ids") or []
                self.store.mark_submitted(accepted)
                self.session_submitted += len(accepted)
                self.root.after(0, self.relay_status_var.set, f"Connected — submitted {len(accepted)}")
                if accepted:
                    self._log_recent(f"Uploaded {len(accepted)} sighting(s) to central relay")
                return len(accepted)
            except Exception as e:
                self.store.mark_attempt_error(ids, e)
                self.root.after(0, self.relay_status_var.set, f"Offline / retrying later: {e}")
                return 0
        finally:
            self.sync_lock.release()

    def _sync_worker(self):
        while not self.sync_stop.is_set():
            self._sync_once()
            interval = max(15, int(self.config.get("sync_interval_seconds", 60)))
            self.sync_stop.wait(interval)

    def start(self):
        if not tgc_terms_accepted("standalone"):
            raise PermissionError("TGC Terms of Use not accepted.")
        self.save_from_ui_silent()
        # Fetch the canonical display name assigned in Apps Script without
        # blocking startup. The node can continue collecting offline if the
        # relay is temporarily unavailable.
        threading.Thread(
            target=self._refresh_relay_identity,
            kwargs={"update_status": True},
            daemon=True,
        ).start()
        self.watcher.start()
        if not self.sync_thread or not self.sync_thread.is_alive():
            self.sync_stop.clear()
            self.sync_thread = threading.Thread(target=self._sync_worker, daemon=True)
            self.sync_thread.start()
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self._log_recent("Node started")

    def stop(self):
        self.watcher.stop()
        self.sync_stop.set()
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self._log_recent("Node stopped")

    def _refresh_ui(self):
        total, pending, submitted = self.store.counts()
        self.count_var.set(
            f"Seen {self.session_seen} | New {self.session_new} | Local duplicates {self.session_duplicates} | "
            f"Uploaded this session {self.session_submitted} | Waiting {pending}"
        )
        while True:
            try:
                msg = self.recent_messages.get_nowait()
            except queue.Empty:
                break
            self.recent.config(state=tk.NORMAL)
            self.recent.insert(tk.END, msg + "\n")
            self.recent.see(tk.END)
            self.recent.config(state=tk.DISABLED)
        self.root.after(500, self._refresh_ui)
        if self.config.get("relay_url") and self.config.get("node_id") and self.config.get("node_key_runtime"):
            self.root.after(1400, lambda: self.check_for_updates(silent=True))

    def close(self):
        try:
            self.stop()
            self.save_from_ui_silent()
        finally:
            self.root.destroy()


def main():
    root = tk.Tk()
    root.geometry("900x650")
    if not tgc_terms_require(root, "standalone"):
        root.destroy()
        return
    TGCInviteNode(root)
    root.mainloop()


if __name__ == "__main__":
    main()
