@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TGC Invite Node Launcher

:detect_python
set "PYEXE="
set "PYARGS="

rem Prefer the Windows Python launcher when available.
where py >nul 2>&1
if not errorlevel 1 (
    py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
    if not errorlevel 1 (
        set "PYEXE=py"
        set "PYARGS=-3"
        goto :python_found
    )
)

rem Then try python.exe on PATH.
where python >nul 2>&1
if not errorlevel 1 (
    python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
    if not errorlevel 1 (
        set "PYEXE=python"
        set "PYARGS="
        goto :python_found
    )
)

rem Finally check normal per-user CPython install locations. This also lets us
rem find Python immediately after a winget install before PATH refreshes.
for %%P in (
    "%LocalAppData%\Programs\Python\Python314\python.exe"
    "%LocalAppData%\Programs\Python\Python313\python.exe"
    "%LocalAppData%\Programs\Python\Python312\python.exe"
    "%LocalAppData%\Programs\Python\Python311\python.exe"
    "%LocalAppData%\Programs\Python\Python310\python.exe"
    "%LocalAppData%\Programs\Python\Python39\python.exe"
    "%LocalAppData%\Programs\Python\Python38\python.exe"
) do (
    if exist "%%~P" (
        "%%~P" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
        if not errorlevel 1 (
            set "PYEXE=%%~P"
            set "PYARGS="
            goto :python_found
        )
    )
)

goto :python_missing

:python_found
echo.
echo [OK] Compatible Python found.
%PYEXE% %PYARGS% -c "import sys; print('     Python ' + sys.version.split()[0] + ' at ' + sys.executable)"

rem Tkinter is the only GUI dependency and should be bundled with normal
rem Windows CPython. The node intentionally has no third-party pip packages.
%PYEXE% %PYARGS% -c "import tkinter, sqlite3, urllib.request, json; print('     Tkinter and required standard-library modules are available.')" >nul 2>&1
if errorlevel 1 goto :tkinter_missing

echo [OK] Node dependencies are ready. No pip install is required.
echo.
goto :check_node_files

:check_node_files
if not exist "%~dp0tgc_invite_node.py" goto :node_files_missing
if not exist "%~dp0tgc_vrchat_multilog.py" goto :node_files_missing

echo Starting TGC Invite Node...
echo.
%PYEXE% %PYARGS% "%~dp0tgc_invite_node.py"
set "NODE_EXIT=%ERRORLEVEL%"

if "%NODE_EXIT%"=="0" goto :done

echo.
echo [ERROR] TGC Invite Node exited with code %NODE_EXIT%.
echo If an error was printed above, send it to Seawolf for troubleshooting.
echo.
pause
exit /b %NODE_EXIT%

:node_files_missing
echo.
echo ================================================================
echo  TGC Invite Node Files Not Available
 echo ================================================================
echo.
echo Python is installed correctly, but the node Python files are not visible
 echo beside this launcher.
echo.
echo This usually happens when run_node.bat is opened DIRECTLY INSIDE THE ZIP.
echo Windows may run only the BAT file from a temporary folder and leave the
 echo Python files behind inside the compressed archive.
echo.
echo FIX:
echo   1. Close this window.
echo   2. Right-click the TGC Node ZIP.
echo   3. Choose "Extract All..."
echo   4. Open the extracted folder.
echo   5. Run run_node.bat from that extracted folder.
echo.
echo The extracted folder must contain BOTH:
echo   tgc_invite_node.py
echo   tgc_vrchat_multilog.py
echo.
pause
exit /b 1

:python_missing
echo.
echo ================================================================
echo  TGC Invite Node - Python Setup Required
 echo ================================================================
echo.
echo Python 3.8 or newer was not found on this computer.
echo The node has no third-party Python dependencies; it only needs a
 echo normal Windows Python installation with Tkinter included.
echo.
echo [I] Install Python automatically with Windows Package Manager
 echo [O] Open the official Python Windows download page
 echo [Q] Quit
 echo.
choice /C IOQ /N /M "Choose I, O, or Q: "
if errorlevel 3 exit /b 1
if errorlevel 2 goto :open_python_download
if errorlevel 1 goto :install_python

:install_python
where winget >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] Windows Package Manager ^(winget^) is not available.
    echo Opening the official Python download page instead.
    goto :open_python_download
)

echo.
echo Installing Python for the current Windows user...
echo This may take a minute and may show a Windows installer prompt.
echo.

rem Prefer a current CPython release, with fallbacks for machines whose
rem winget catalog does not yet expose the newest package ID.
winget install --id Python.Python.3.13 -e --scope user --accept-source-agreements --accept-package-agreements
if not errorlevel 1 goto :install_finished
winget install --id Python.Python.3.12 -e --scope user --accept-source-agreements --accept-package-agreements
if not errorlevel 1 goto :install_finished
winget install --id Python.Python.3.11 -e --scope user --accept-source-agreements --accept-package-agreements
if not errorlevel 1 goto :install_finished

echo.
echo [ERROR] Automatic Python installation failed.
echo Opening the official Python download page instead.
goto :open_python_download

:install_finished
echo.
echo [OK] Python installation completed.
echo Re-checking this computer now...
echo.
goto :detect_python

:tkinter_missing
echo.
echo ================================================================
echo  Python Found, But Tkinter Is Missing
 echo ================================================================
echo.
echo The installed Python does not include Tkinter, which the node GUI needs.
echo A normal python.org Windows installation includes Tkinter by default.
echo.
echo [R] Reinstall a standard Python build automatically with winget
 echo [O] Open the official Python Windows download page
 echo [Q] Quit
 echo.
choice /C ROQ /N /M "Choose R, O, or Q: "
if errorlevel 3 exit /b 1
if errorlevel 2 goto :open_python_download
if errorlevel 1 goto :install_python

:open_python_download
start "" "https://www.python.org/downloads/windows/"
echo.
echo Install Python 3.8 or newer, then run this launcher again.
echo During a manual install, leave the Tcl/Tk and IDLE feature enabled.
echo.
pause
exit /b 1

:done
endlocal
exit /b 0
