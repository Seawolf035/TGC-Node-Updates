#!/usr/bin/env python3
import hashlib
import json
import os
import queue
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import urllib.parse
import uuid
import zipfile
from datetime import datetime, timezone
import tkinter as tk
from tkinter import ttk, messagebox
from tgc_vrchat_multilog import MultiVRChatLogWatcher

APP_VERSION = "1.1.8"
HOTFIX_REVISION = 0
CLIENT_TYPE = "standalone"
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/Seawolf035/TGC-Node-Updates/main/manifest.json"
MAX_UPDATE_DOWNLOAD_BYTES = 100 * 1024 * 1024
USER_ID_RE = re.compile(r"\busr_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b")
JOIN_RE = re.compile(r"OnPlayerJoined\s+(.+?)\s+\((usr_[0-9a-fA-F-]{36})\)")
TIMESTAMP_RE = re.compile(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})")


class _DATA_BLOB(__import__("ctypes").Structure):
    _fields_ = [
        ("cbData", __import__("ctypes").c_ulong),
        ("pbData", __import__("ctypes").POINTER(__import__("ctypes").c_char)),
    ]


def _dpapi_protect(raw: bytes, description="TGC Invite Node Key") -> bytes:
    if os.name != "nt":
        raise RuntimeError("Windows DPAPI is only available on Windows")
    import ctypes
    in_buffer = ctypes.create_string_buffer(raw)
    in_blob = _DATA_BLOB(len(raw), ctypes.cast(in_buffer, ctypes.POINTER(ctypes.c_char)))
    out_blob = _DATA_BLOB()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    ok = crypt32.CryptProtectData(
        ctypes.byref(in_blob), ctypes.c_wchar_p(description), None, None, None, 0,
        ctypes.byref(out_blob),
    )
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(out_blob.pbData)


def _dpapi_unprotect(blob: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("Windows DPAPI is only available on Windows")
    import ctypes
    in_buffer = ctypes.create_string_buffer(blob)
    in_blob = _DATA_BLOB(len(blob), ctypes.cast(in_buffer, ctypes.POINTER(ctypes.c_char)))
    out_blob = _DATA_BLOB()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    ok = crypt32.CryptUnprotectData(
        ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)
    )
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(out_blob.pbData)


class LocalStore:
    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()
        self._init()

    def _con(self):
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        return con

    def _init(self):
        with self._con() as con:
            con.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS sightings (
                    event_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    display_name TEXT,
                    seen_at TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_sightings_status ON sightings(status, created_at);
                CREATE TABLE IF NOT EXISTS recent_users (
                    user_id TEXT PRIMARY KEY,
                    last_seen_at TEXT NOT NULL
                );
                """
            )

    def add_sighting(self, user_id, display_name, seen_at, dedupe_minutes=60):
        now = datetime.now(timezone.utc)
        with self.lock, self._con() as con:
            row = con.execute("SELECT last_seen_at FROM recent_users WHERE user_id=?", (user_id,)).fetchone()
            if row:
                try:
                    last = datetime.fromisoformat(row["last_seen_at"].replace("Z", "+00:00"))
                    if (now - last).total_seconds() < max(0, dedupe_minutes) * 60:
                        con.execute("UPDATE recent_users SET last_seen_at=? WHERE user_id=?", (now.isoformat(), user_id))
                        return False, None
                except Exception:
                    pass
            event_id = "evt_" + uuid.uuid4().hex
            con.execute(
                "INSERT INTO sightings(event_id,user_id,display_name,seen_at,created_at,status) VALUES(?,?,?,?,?, 'pending')",
                (event_id, user_id, display_name, seen_at, now.isoformat()),
            )
            con.execute(
                "INSERT INTO recent_users(user_id,last_seen_at) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET last_seen_at=excluded.last_seen_at",
                (user_id, now.isoformat()),
            )
            return True, event_id

    def pending(self, limit=100):
        with self.lock, self._con() as con:
            rows = con.execute(
                "SELECT * FROM sightings WHERE status='pending' ORDER BY created_at ASC LIMIT ?", (int(limit),)
            ).fetchall()
            return [dict(r) for r in rows]

    def mark_submitted(self, event_ids):
        if not event_ids:
            return
        with self.lock, self._con() as con:
            con.executemany("UPDATE sightings SET status='submitted', last_error=NULL WHERE event_id=?", [(x,) for x in event_ids])

    def mark_attempt_error(self, event_ids, error):
        if not event_ids:
            return
        with self.lock, self._con() as con:
            con.executemany(
                "UPDATE sightings SET attempts=attempts+1, last_error=? WHERE event_id=?",
                [(str(error)[:1000], x) for x in event_ids],
            )

    def counts(self):
        with self.lock, self._con() as con:
            pending = con.execute("SELECT COUNT(*) FROM sightings WHERE status='pending'").fetchone()[0]
            submitted = con.execute("SELECT COUNT(*) FROM sightings WHERE status='submitted'").fetchone()[0]
            total = con.execute("SELECT COUNT(*) FROM sightings").fetchone()[0]
            return total, pending, submitted



class TGCInviteNode:
    def __init__(self, root):
        self.root = root
        self.root.title("TGC Invite Node")
        self.base = os.path.dirname(os.path.abspath(__file__))
        self.config_path = os.path.join(self.base, "node_config.json")
        self.key_path = os.path.join(self.base, "node_key.dpapi")
        self.store = LocalStore(os.path.join(self.base, "node_queue.db"))
        self.config = self._load_config()

        self.sync_stop = threading.Event()
        self.sync_thread = None
        self.sync_lock = threading.Lock()
        self.session_seen = 0
        self.session_new = 0
        self.session_duplicates = 0
        self.session_submitted = 0
        self.recent_messages = queue.Queue()
        self.release_info = {}
        self.update_required = False
        self.update_in_progress = False
        self.update_notice_shown_for = ""

        self.watcher = MultiVRChatLogWatcher(self._on_join, self._set_watcher_status)
        self._build_ui()
        self.root.after(500, self._refresh_ui)
        if self.config.get("relay_url") and self.config.get("node_id") and self.config.get("node_key_runtime"):
            self.root.after(1400, lambda: self.check_for_updates(silent=True))

    def _default_config(self):
        return {
            "relay_url": "",
            "node_id": "",
            "node_name": "",
            "install_id": "",
            "sync_interval_seconds": 60,
            "batch_size": 100,
            "local_dedupe_minutes": 60,
            "auto_start": True,
            "ignore_user_ids": [],
        }

    def _load_protected_key(self):
        if not os.path.isfile(self.key_path):
            return ""
        try:
            with open(self.key_path, "rb") as f:
                protected = f.read()
            if not protected:
                return ""
            return _dpapi_unprotect(protected).decode("utf-8")
        except Exception:
            return ""

    def _save_protected_key(self, value):
        value = str(value or "")
        if not value:
            try:
                if os.path.exists(self.key_path):
                    os.remove(self.key_path)
            except OSError:
                pass
            return
        protected = _dpapi_protect(value.encode("utf-8"))
        tmp = self.key_path + ".tmp"
        with open(tmp, "wb") as f:
            f.write(protected)
        os.replace(tmp, self.key_path)

    def _load_config(self):
        data = self._default_config()
        legacy_key = ""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                if isinstance(loaded, dict):
                    legacy_key = str(loaded.pop("node_key", "") or "")
                    loaded.pop("node_key_runtime", None)
                    data.update(loaded)
        except Exception:
            pass
        if not str(data.get("install_id") or "").strip():
            data["install_id"] = uuid.uuid4().hex
        protected_key = self._load_protected_key()
        data["node_key_runtime"] = protected_key or legacy_key
        if legacy_key and not protected_key and os.name == "nt":
            try:
                self._save_protected_key(legacy_key)
                payload = dict(data)
                payload.pop("node_key_runtime", None)
                with open(self.config_path, "w", encoding="utf-8") as f:
                    json.dump(payload, f, indent=2)
            except Exception:
                pass
        return data

    def _save_config(self):
        payload = dict(self.config)
        raw_key = str(payload.pop("node_key_runtime", "") or "")
        payload.pop("node_key", None)
        tmp = self.config_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        os.replace(tmp, self.config_path)
        self._save_protected_key(raw_key)

    def _build_ui(self):
        frame = ttk.Frame(self.root)
        frame.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)
        ttk.Label(frame, text="The Gamer Club — Invite Node", font=("Segoe UI", 16, "bold")).pack(anchor=tk.W)
        ttk.Label(
            frame,
            text="Watches every active VRChat instance on this PC and reports encountered user IDs to the TGC Google relay. This node contains no VRChat login credentials.",
            wraplength=760,
        ).pack(anchor=tk.W, pady=(2, 10))

        deploy = ttk.LabelFrame(frame, text="Quick Deployment")
        deploy.pack(fill=tk.X, pady=(0, 10))
        deploy.columnconfigure(0, weight=1)
        ttk.Label(
            deploy,
            text="Paste the one-time TGC deployment link from an owner. It contains the relay address, so there is no Node ID, Node Key, or Apps Script URL to type manually.",
            wraplength=760,
            justify=tk.LEFT,
        ).grid(row=0, column=0, columnspan=2, sticky=tk.W, padx=6, pady=(5, 3))
        self.deploy_var = tk.StringVar()
        ttk.Entry(deploy, textvariable=self.deploy_var).grid(row=1, column=0, sticky=tk.EW, padx=6, pady=(3, 6))
        ttk.Button(deploy, text="Deploy This Node", command=self.redeem_deployment).grid(row=1, column=1, sticky=tk.E, padx=6, pady=(3, 6))

        settings = ttk.LabelFrame(frame, text="Node Preferences")
        settings.pack(fill=tk.X, pady=(0, 10))
        settings.columnconfigure(1, weight=1)
        self.url_var = tk.StringVar(value=self.config.get("relay_url", ""))
        self.node_id_var = tk.StringVar(value=self.config.get("node_id", ""))
        self.key_var = tk.StringVar(value=self.config.get("node_key_runtime", ""))
        self.name_var = tk.StringVar(value=self.config.get("node_name", ""))
        self.interval_var = tk.IntVar(value=int(self.config.get("sync_interval_seconds", 60)))
        self.dedupe_var = tk.IntVar(value=int(self.config.get("local_dedupe_minutes", 60)))

        ttk.Label(settings, text="Node:").grid(row=0, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings, textvariable=self.name_var).grid(row=0, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings, text="Enrollment is managed exclusively through Quick Deployment.", wraplength=690).grid(row=1, column=0, columnspan=4, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings, text="Sync Interval:").grid(row=4, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Spinbox(settings, from_=15, to=3600, increment=15, textvariable=self.interval_var).grid(row=4, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings, text="seconds").grid(row=4, column=2, sticky=tk.W)
        ttk.Label(settings, text="Local Repeat Dedupe:").grid(row=5, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Spinbox(settings, from_=0, to=10080, textvariable=self.dedupe_var).grid(row=5, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings, text="minutes").grid(row=5, column=2, sticky=tk.W)
        btns = ttk.Frame(settings)
        btns.grid(row=6, column=0, columnspan=4, sticky=tk.W, padx=6, pady=6)
        ttk.Button(btns, text="Save", command=self.save_from_ui).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btns, text="Test Relay", command=self.test_relay).pack(side=tk.LEFT, padx=5)
        ttk.Button(btns, text="Sync Now", command=self.sync_now).pack(side=tk.LEFT, padx=5)

        updates = ttk.LabelFrame(frame, text="Node Updates")
        updates.pack(fill=tk.X, pady=(0, 10))
        updates.columnconfigure(0, weight=1)
        self.update_status_var = tk.StringVar(value=f"Installed: v{APP_VERSION} — update status not checked")
        ttk.Label(
            updates,
            textvariable=self.update_status_var,
            wraplength=690,
            justify=tk.LEFT,
        ).grid(row=0, column=0, sticky=tk.W, padx=6, pady=5)
        update_buttons = ttk.Frame(updates)
        update_buttons.grid(row=0, column=1, sticky=tk.E, padx=6, pady=5)
        ttk.Button(
            update_buttons,
            text="Check for Updates",
            command=self.check_for_updates,
        ).pack(side=tk.LEFT, padx=(0, 5))
        self.install_update_btn = ttk.Button(
            update_buttons,
            text="Install Update",
            command=self.install_update,
            state=tk.DISABLED,
        )
        self.install_update_btn.pack(side=tk.LEFT)

        status = ttk.LabelFrame(frame, text="Status")
        status.pack(fill=tk.X, pady=(0, 10))
        self.watcher_status_var = tk.StringVar(value="Stopped")
        self.instances_var = tk.StringVar(value="0")
        self.players_var = tk.StringVar(value="0")
        self.relay_status_var = tk.StringVar(value="Not tested")
        self.count_var = tk.StringVar(value="")
        ttk.Label(status, text="VRChat Logs:").grid(row=0, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, textvariable=self.watcher_status_var).grid(row=0, column=1, columnspan=3, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, text="Active Instances:").grid(row=1, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, textvariable=self.instances_var, font=("Segoe UI", 10, "bold")).grid(row=1, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, text="Tracked Players:").grid(row=1, column=2, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, textvariable=self.players_var, font=("Segoe UI", 10, "bold")).grid(row=1, column=3, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, text="Relay:").grid(row=2, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, textvariable=self.relay_status_var).grid(row=2, column=1, columnspan=3, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, text="Session:").grid(row=3, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Label(status, textvariable=self.count_var).grid(row=3, column=1, columnspan=3, sticky=tk.W, padx=6, pady=4)

        actions = ttk.Frame(frame)
        actions.pack(fill=tk.X, pady=(0, 10))
        self.start_btn = ttk.Button(actions, text="Start Node", command=self.start)
        self.start_btn.pack(side=tk.LEFT, padx=(0, 6))
        self.stop_btn = ttk.Button(actions, text="Stop", command=self.stop, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=6)

        recent_frame = ttk.LabelFrame(frame, text="Recent Sightings")
        recent_frame.pack(fill=tk.BOTH, expand=True)
        self.recent = tk.Text(recent_frame, height=12, wrap=tk.WORD, state=tk.DISABLED)
        self.recent.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)

        self.root.protocol("WM_DELETE_WINDOW", self.close)
        if self.config.get("auto_start"):
            self.root.after(700, self.start)

    def save_from_ui(self):
        self.config.update({
            "sync_interval_seconds": max(15, int(self.interval_var.get())),
            "local_dedupe_minutes": max(0, int(self.dedupe_var.get())),
        })
        self._save_config()
        messagebox.showinfo("TGC Invite Node", "Configuration saved.")

    def _set_watcher_status(self, summary):
        if isinstance(summary, dict):
            self.root.after(0, self.watcher_status_var.set, summary.get("message", "Watching VRChat logs"))
            self.root.after(0, self.instances_var.set, str(summary.get("active_logs", 0)))
            self.root.after(0, self.players_var.set, str(summary.get("active_players", 0)))
        else:
            self.root.after(0, self.watcher_status_var.set, str(summary))

    def _log_recent(self, msg):
        self.recent_messages.put(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

    def _on_join(self, user_id, display_name, seen_at, source_log=None):
        self.session_seen += 1
        if user_id in set(self.config.get("ignore_user_ids") or []):
            return
        added, _ = self.store.add_sighting(
            user_id, display_name, seen_at, int(self.config.get("local_dedupe_minutes", 60))
        )
        if added:
            self.session_new += 1
            source = os.path.basename(source_log) if source_log else "VRChat"
            self._log_recent(f"Queued: {display_name} ({user_id}) — {source}")
        else:
            self.session_duplicates += 1
            self._log_recent(f"Local duplicate: {display_name}")

    def _post_to_url(self, url, payload, timeout=25):
        url = str(url or "").strip()
        if not url.lower().startswith("https://"):
            raise RuntimeError("Relay URL is missing or invalid")
        raw = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=raw,
            headers={"Content-Type": "application/json", "User-Agent": f"TGC-Invite-Node/{APP_VERSION}"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode("utf-8", errors="replace"))
        if not result.get("ok"):
            raise RuntimeError(result.get("error") or "Relay rejected request")
        return result

    def _parse_deployment_input(self, value):
        value = str(value or "").strip()
        if not value:
            raise RuntimeError("Paste the deployment link or code from a TGC owner")
        relay_url = str(self.config.get("relay_url") or "").strip()
        code = value.upper()
        if value.lower().startswith("https://"):
            parsed = urllib.parse.urlsplit(value)
            query = urllib.parse.parse_qs(parsed.query)
            code = str((query.get("deploy") or [""])[0]).strip().upper()
            relay_url = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, "", ""))
        if not re.fullmatch(r"TGC-DEPLOY(?:-[A-F0-9]{4}){5}", code):
            raise RuntimeError("That is not a valid TGC deployment code/link")
        if not relay_url.lower().startswith("https://"):
            raise RuntimeError("This fresh install needs the full deployment link, not only the short code")
        return relay_url, code

    def redeem_deployment(self):
        try:
            relay_url, code = self._parse_deployment_input(self.deploy_var.get())
        except Exception as error:
            messagebox.showerror("Deploy TGC Invite Node", str(error))
            return
        install_id = str(self.config.get("install_id") or "").strip() or uuid.uuid4().hex
        self.config["install_id"] = install_id
        try:
            self._save_config()
        except Exception:
            pass
        self.relay_status_var.set("Redeeming one-time deployment code…")

        def worker():
            try:
                data = self._post_to_url(
                    relay_url,
                    {
                        "action": "redeem_deployment",
                        "code": code,
                        "client_type": CLIENT_TYPE,
                        "version": APP_VERSION,
                        "install_id": install_id,
                    },
                    timeout=30,
                )
                node_id = str(data.get("node_id") or "").strip()
                node_key = str(data.get("node_key") or "").strip()
                node_name = str(data.get("node_name") or "").strip()
                discord_id = str(data.get("discord_id") or "").strip()
                if not node_id or not node_key:
                    raise RuntimeError("Relay did not return complete node credentials")
                self.config.update({
                    "relay_url": relay_url,
                    "node_id": node_id,
                    "node_key_runtime": node_key,
                    "node_name": node_name,
                    "auto_start": True,
                })
                self._save_config()

                def finish():
                    self.url_var.set(relay_url)
                    self.node_id_var.set(node_id)
                    self.key_var.set(node_key)
                    self.name_var.set(node_name)
                    self.deploy_var.set("")
                    self.root.title(f"TGC Invite Node — {node_name}" if node_name else "TGC Invite Node")
                    self.relay_status_var.set(f"Deployed and verified — {node_name or node_id}")
                    messagebox.showinfo(
                        "TGC Invite Node Deployed",
                        "Deployment complete.\n\n"
                        f"Node: {node_name or node_id}\n"
                        + (f"Staff Discord ID: {discord_id}\n" if discord_id else "")
                        + "\nThe permanent Node Key is protected with Windows DPAPI. The node will now start automatically.",
                    )
                    self.start()
                    self.check_for_updates(silent=True)
                self.root.after(0, finish)
            except Exception as error:
                self.root.after(0, self.relay_status_var.set, f"Deployment failed: {error}")
                self.root.after(0, lambda err=error: messagebox.showerror("Deploy TGC Invite Node", str(err)))

        threading.Thread(target=worker, daemon=True, name="NodeDeployment").start()

    def _post(self, payload, timeout=25):
        url = self.config.get("relay_url", "").strip()
        if not url:
            raise RuntimeError("Relay URL is not configured")
        return self._post_to_url(url, payload, timeout=timeout)

    def _auth_payload(self, action, **extra):
        node_id = self.config.get("node_id", "").strip()
        node_key = self.config.get("node_key_runtime", "").strip()
        if not node_id or not node_key:
            raise RuntimeError("Node ID / Node Key are not configured")
        # The relay/Apps Script is authoritative for the node's display name.
        # Do not send a local node_name back, otherwise touchNode_() would be
        # allowed to overwrite the name assigned centrally in the Nodes sheet.
        payload = {
            "action": action,
            "node_id": node_id,
            "node_key": node_key,
            "version": APP_VERSION,
            "client_type": CLIENT_TYPE,
        }
        payload.update(extra)
        return payload

    def _apply_relay_identity(self, data):
        canonical_name = str((data or {}).get("node_name") or "").strip()
        if not canonical_name:
            return
        self.config["node_name"] = canonical_name
        try:
            self._save_config()
        except Exception:
            pass

        def apply_ui():
            self.name_var.set(canonical_name)
            self.root.title(f"TGC Invite Node — {canonical_name}")

        self.root.after(0, apply_ui)

    def _refresh_relay_identity(self, update_status=True):
        try:
            data = self._post(self._auth_payload("node_status"))
            self._apply_relay_identity(data)
            canonical_name = str(data.get("node_name") or "").strip()
            if update_status:
                label = canonical_name or self.config.get("node_id", "")
                self.root.after(0, self.relay_status_var.set, f"Connected — {label}")
            return data
        except Exception as e:
            if update_status:
                self.root.after(0, self.relay_status_var.set, f"Error: {e}")
            return None

    @staticmethod
    def _version_tuple(value):
        text = str(value or "").strip().lower().replace("-plugin", "")
        match = re.search(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?", text)
        if not match:
            return (0, 0, 0)
        return tuple(int(part or 0) for part in match.groups())

    def _fetch_github_release(self):
        request = urllib.request.Request(
            UPDATE_MANIFEST_URL,
            headers={
                "Accept": "application/json",
                "Cache-Control": "no-cache",
                "User-Agent": f"TGC-Invite-Node-Updater/{APP_VERSION}",
            },
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            raw = response.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise RuntimeError("GitHub update manifest returned invalid JSON.")
        releases = data.get("releases") or {}
        release = releases.get(CLIENT_TYPE) if isinstance(releases, dict) else None
        if not isinstance(release, dict):
            raise RuntimeError("GitHub update manifest has no standalone release entry.")
        return release

    def _release_available(self, info):
        if not isinstance(info, dict):
            return False
        version = str(info.get("version") or "").strip()
        if not version:
            return False
        remote = self._version_tuple(version)
        installed = self._version_tuple(APP_VERSION)
        if remote != installed:
            return remote > installed
        try:
            return int(info.get("hotfix_revision") or 0) > HOTFIX_REVISION
        except (TypeError, ValueError):
            return False

    def _apply_release_info(self, release):
        if not isinstance(release, dict):
            return
        channel = str(release.get("channel") or CLIENT_TYPE).strip().lower()
        if channel and channel != CLIENT_TYPE:
            return
        version = str(release.get("version") or "").strip()
        if not version:
            return
        info = dict(release)
        info["version"] = version
        info["policy"] = str(info.get("policy") or "optional").strip().lower()
        self.release_info = info
        available = self._release_available(info)
        self.update_required = available and info["policy"] == "required"

        def apply_ui():
            if available:
                policy = info["policy"].capitalize()
                self.update_status_var.set(
                    f"Update available: v{version} — {policy}"
                    + (f" — {str(info.get('notes') or '').strip()}" if info.get("notes") else "")
                )
                self.install_update_btn.config(state=tk.NORMAL if not self.update_in_progress else tk.DISABLED)
                update_id = f"{version}:hotfix{info.get('hotfix_revision', 0)}"
                if info["policy"] in {"recommended", "required"} and self.update_notice_shown_for != update_id:
                    self.update_notice_shown_for = update_id
                    detail = (
                        f"TGC Invite Node v{version} is {info['policy']}.\n\n"
                        + (str(info.get("notes") or "").strip() + "\n\n" if info.get("notes") else "")
                    )
                    if info["policy"] == "required":
                        detail += "Sightings will continue to be buffered locally, but relay uploads are paused until you update."
                    else:
                        detail += "Please install the update when practical."
                    messagebox.showwarning("TGC Invite Node Update", detail)
            else:
                self.update_status_var.set(f"Installed: v{APP_VERSION} — current")
                self.install_update_btn.config(state=tk.DISABLED)
        self.root.after(0, apply_ui)

    def check_for_updates(self, silent=False):
        try:
            self.save_from_ui_silent()
        except Exception as error:
            if not silent:
                messagebox.showerror("TGC Invite Node", str(error))
            return

        def worker():
            try:
                release = self._fetch_github_release()
                self._apply_release_info(release)
                if not silent and not self._release_available(release):
                    self.root.after(0, lambda: messagebox.showinfo("TGC Invite Node", f"This node is current (v{APP_VERSION})."))
            except Exception as error:
                self.root.after(0, self.update_status_var.set, f"GitHub update check failed: {error}")
                if not silent:
                    self.root.after(0, lambda err=error: messagebox.showerror("TGC Invite Node", f"Could not check GitHub for updates:\n\n{err}"))

        threading.Thread(target=worker, daemon=True, name="NodeUpdateCheck").start()

    @staticmethod
    def _safe_zip_members(zf):
        members = []
        for info in zf.infolist():
            name = info.filename.replace("\\", "/")
            if not name or name.endswith("/"):
                continue
            if name.startswith("/") or ".." in name.split("/"):
                raise RuntimeError(f"Unsafe path in update package: {name}")
            members.append((info, name))
        return members

    def _download_and_stage_update(self, info):
        version = str(info.get("version") or "").strip()
        url = str(info.get("url") or "").strip()
        expected_hash = str(info.get("sha256") or "").strip().lower()
        if not version or not url or not expected_hash:
            raise RuntimeError("The GitHub release metadata is incomplete.")
        if not url.lower().startswith("https://"):
            raise RuntimeError("Update downloads must use HTTPS.")
        if not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
            raise RuntimeError("The GitHub release SHA-256 is invalid.")

        updates_dir = os.path.join(self.base, "updates")
        os.makedirs(updates_dir, exist_ok=True)
        temp_zip = os.path.join(updates_dir, f"node_update_{version}.zip.part")
        digest = hashlib.sha256()
        downloaded = 0
        req = urllib.request.Request(url, headers={"User-Agent": f"TGC-Invite-Node-Updater/{APP_VERSION}"})
        with urllib.request.urlopen(req, timeout=60) as response, open(temp_zip, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                downloaded += len(chunk)
                if downloaded > MAX_UPDATE_DOWNLOAD_BYTES:
                    raise RuntimeError("Update package is unexpectedly large.")
                digest.update(chunk)
                output.write(chunk)
        actual_hash = digest.hexdigest().lower()
        if actual_hash != expected_hash:
            try:
                os.remove(temp_zip)
            except OSError:
                pass
            raise RuntimeError("Update checksum verification failed. The package was not installed.")

        staging = tempfile.mkdtemp(prefix="tgc_node_update_", dir=updates_dir)
        with zipfile.ZipFile(temp_zip, "r") as zf:
            members = self._safe_zip_members(zf)
            names = [name for _, name in members]
            prefixes = {name.split("/", 1)[0] for name in names if "/" in name}
            root_prefix = ""
            if "tgc_invite_node.py" not in names and len(prefixes) == 1:
                candidate = next(iter(prefixes)) + "/"
                if candidate + "tgc_invite_node.py" in names:
                    root_prefix = candidate
            allowed = {
                "tgc_invite_node.py", "tgc_vrchat_multilog.py", "tgc_node_update_helper.py",
                "run_node.bat", "check_python_setup.bat", "build_node_exe.bat",
                "README_NODE.txt", "START_HERE.txt", "node_config.example.json",
            }
            selected = []
            for info_obj, name in members:
                rel = name[len(root_prefix):] if root_prefix and name.startswith(root_prefix) else name
                if rel in allowed:
                    dst = os.path.join(staging, rel)
                    os.makedirs(os.path.dirname(dst) or staging, exist_ok=True)
                    with zf.open(info_obj) as src, open(dst, "wb") as out:
                        shutil.copyfileobj(src, out)
                    selected.append(rel)
        try:
            os.remove(temp_zip)
        except OSError:
            pass
        if "tgc_invite_node.py" not in selected or "tgc_vrchat_multilog.py" not in selected:
            shutil.rmtree(staging, ignore_errors=True)
            raise RuntimeError("Update ZIP does not contain the standalone node program files.")
        with open(os.path.join(staging, "update_manifest.json"), "w", encoding="utf-8") as fh:
            json.dump({"version": version, "files": selected}, fh, indent=2)
        return staging

    def install_update(self):
        info = dict(self.release_info or {})
        version = str(info.get("version") or "").strip()
        if not self._release_available(info):
            messagebox.showinfo("TGC Invite Node", "No newer update is currently available.")
            return
        policy = str(info.get("policy") or "optional").capitalize()
        notes = str(info.get("notes") or "").strip()
        prompt = f"Install TGC Invite Node v{version}?\n\nPolicy: {policy}"
        if notes:
            prompt += f"\n\n{notes}"
        prompt += "\n\nThe node will close, install the verified update, and restart automatically. Your Node ID, Node Key, settings, and queue database are preserved."
        if not messagebox.askyesno("Install Node Update", prompt):
            return
        if self.update_in_progress:
            return
        self.update_in_progress = True
        self.install_update_btn.config(state=tk.DISABLED)
        self.update_status_var.set(f"Downloading v{version}…")

        def worker():
            try:
                staging = self._download_and_stage_update(info)
                helper = os.path.join(self.base, "tgc_node_update_helper.py")
                if not os.path.isfile(helper):
                    helper_src = os.path.join(staging, "tgc_node_update_helper.py")
                    if os.path.isfile(helper_src):
                        shutil.copy2(helper_src, helper)
                if not os.path.isfile(helper):
                    raise RuntimeError("Updater helper is missing from this installation/update package.")
                subprocess.Popen(
                    [sys.executable, helper, "--pid", str(os.getpid()), "--base", self.base, "--staging", staging, "--version", version],
                    cwd=self.base,
                )
                self.root.after(0, self.update_status_var.set, f"Installing v{version} — restarting…")
                self.root.after(500, self._shutdown_for_update)
            except Exception as error:
                self.update_in_progress = False
                self.root.after(0, self.install_update_btn.config, {"state": tk.NORMAL})
                self.root.after(0, self.update_status_var.set, f"Update failed: {error}")
                self.root.after(0, lambda err=error: messagebox.showerror("Node Update Failed", str(err)))

        threading.Thread(target=worker, daemon=True, name="NodeUpdater").start()

    def _shutdown_for_update(self):
        try:
            self.stop()
            self.save_from_ui_silent()
        finally:
            self.root.destroy()

    def test_relay(self):
        self.save_from_ui_silent()
        threading.Thread(
            target=self._refresh_relay_identity,
            kwargs={"update_status": True},
            daemon=True,
        ).start()

    def generate_discord_link_code(self):
        self.save_from_ui_silent()

        def worker():
            try:
                data = self._post(self._auth_payload("create_node_link_code"))
                self._apply_relay_identity(data)
                code = str(data.get("code") or "").strip()
                expires_at = str(data.get("expires_at") or "").strip()
                node_name = str(data.get("node_name") or self.config.get("node_name") or "this node")
                if not code:
                    raise RuntimeError("Relay did not return a Discord link code")

                def show_code():
                    try:
                        self.root.clipboard_clear()
                        self.root.clipboard_append(code)
                        self.root.update_idletasks()
                    except Exception:
                        pass
                    self.relay_status_var.set(f"Discord link code ready — {code}")
                    messagebox.showinfo(
                        "Link Node to Discord",
                        (
                            f"Node: {node_name}\n\n"
                            f"Your one-time Discord link code is:\n\n{code}\n\n"
                            "The code has been copied to your clipboard.\n"
                            "In the TGC Discord, run:\n"
                            f"/verifynode code:{code}\n\n"
                            "This code expires in 10 minutes and can only be used once."
                            + (f"\nExpires: {expires_at}" if expires_at else "")
                        ),
                    )

                self.root.after(0, show_code)
            except Exception as error:
                self.root.after(0, self.relay_status_var.set, f"Link error: {error}")
                self.root.after(
                    0,
                    lambda err=error: messagebox.showerror(
                        "Link Node to Discord",
                        str(err),
                    ),
                )

        threading.Thread(
            target=worker,
            daemon=True,
            name="NodeDiscordLinkCode",
        ).start()

    def save_from_ui_silent(self):
        self.config.update({
            "sync_interval_seconds": max(15, int(self.interval_var.get())),
            "local_dedupe_minutes": max(0, int(self.dedupe_var.get())),
        })
        self._save_config()

    def sync_now(self):
        self.save_from_ui_silent()
        threading.Thread(target=self._sync_once, daemon=True).start()

    def _sync_once(self):
        if self.update_required:
            self.root.after(0, self.relay_status_var.set, "Required update — sightings are being buffered locally")
            return 0
        if not self.sync_lock.acquire(blocking=False):
            return 0
        try:
            batch = self.store.pending(int(self.config.get("batch_size", 100)))
            if not batch:
                self.root.after(0, self.relay_status_var.set, "Connected — nothing queued")
                return 0
            sightings = [
                {
                    "event_id": r["event_id"],
                    "user_id": r["user_id"],
                    "display_name": r.get("display_name") or r["user_id"],
                    "seen_at": r["seen_at"],
                }
                for r in batch
            ]
            ids = [r["event_id"] for r in batch]
            try:
                result = self._post(self._auth_payload("submit_sightings", sightings=sightings))
                accepted = result.get("accepted_event_ids") or []
                self.store.mark_submitted(accepted)
                self.session_submitted += len(accepted)
                self.root.after(0, self.relay_status_var.set, f"Connected — submitted {len(accepted)}")
                if accepted:
                    self._log_recent(f"Uploaded {len(accepted)} sighting(s) to central relay")
                return len(accepted)
            except Exception as e:
                self.store.mark_attempt_error(ids, e)
                self.root.after(0, self.relay_status_var.set, f"Offline / retrying later: {e}")
                return 0
        finally:
            self.sync_lock.release()

    def _sync_worker(self):
        while not self.sync_stop.is_set():
            self._sync_once()
            interval = max(15, int(self.config.get("sync_interval_seconds", 60)))
            self.sync_stop.wait(interval)

    def start(self):
        self.save_from_ui_silent()
        # Fetch the canonical display name assigned in Apps Script without
        # blocking startup. The node can continue collecting offline if the
        # relay is temporarily unavailable.
        threading.Thread(
            target=self._refresh_relay_identity,
            kwargs={"update_status": True},
            daemon=True,
        ).start()
        self.watcher.start()
        if not self.sync_thread or not self.sync_thread.is_alive():
            self.sync_stop.clear()
            self.sync_thread = threading.Thread(target=self._sync_worker, daemon=True)
            self.sync_thread.start()
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self._log_recent("Node started")

    def stop(self):
        self.watcher.stop()
        self.sync_stop.set()
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self._log_recent("Node stopped")

    def _refresh_ui(self):
        total, pending, submitted = self.store.counts()
        self.count_var.set(
            f"Seen {self.session_seen} | New {self.session_new} | Local duplicates {self.session_duplicates} | "
            f"Uploaded this session {self.session_submitted} | Waiting {pending}"
        )
        while True:
            try:
                msg = self.recent_messages.get_nowait()
            except queue.Empty:
                break
            self.recent.config(state=tk.NORMAL)
            self.recent.insert(tk.END, msg + "\n")
            self.recent.see(tk.END)
            self.recent.config(state=tk.DISABLED)
        self.root.after(500, self._refresh_ui)
        if self.config.get("relay_url") and self.config.get("node_id") and self.config.get("node_key_runtime"):
            self.root.after(1400, lambda: self.check_for_updates(silent=True))

    def close(self):
        try:
            self.stop()
            self.save_from_ui_silent()
        finally:
            self.root.destroy()


def main():
    root = tk.Tk()
    root.geometry("900x650")
    TGCInviteNode(root)
    root.mainloop()


if __name__ == "__main__":
    main()
