#!/usr/bin/env python3
"""External updater helper for the standalone TGC Invite Node.

This file uses only the Python standard library. It is launched by the node after
an update package has been downloaded and verified. It waits for the node process
to exit, backs up replaceable program files, applies the staged update, and
restarts the node. Runtime identity/config/database files are never touched.
"""
import argparse
import ctypes
import datetime as _dt
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ALLOWED_FILES = {
    "tgc_invite_node.py",
    "tgc_vrchat_multilog.py",
    "tgc_node_update_helper.py",
    "run_node.bat",
    "check_python_setup.bat",
    "build_node_exe.bat",
    "README_NODE.txt",
    "START_HERE.txt",
    "node_config.example.json",
}


def _pid_running(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        SYNCHRONIZE = 0x00100000
        WAIT_TIMEOUT = 0x00000102
        handle = ctypes.windll.kernel32.OpenProcess(SYNCHRONIZE, False, int(pid))
        if not handle:
            return False
        try:
            return ctypes.windll.kernel32.WaitForSingleObject(handle, 0) == WAIT_TIMEOUT
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _copy_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".update_tmp")
    shutil.copy2(src, tmp)
    os.replace(tmp, dst)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--base", required=True)
    parser.add_argument("--staging", required=True)
    parser.add_argument("--version", required=True)
    args = parser.parse_args()

    base = Path(args.base).resolve()
    staging = Path(args.staging).resolve()
    updates = base / "updates"
    updates.mkdir(parents=True, exist_ok=True)
    log_path = updates / "update.log"

    def log(message: str) -> None:
        stamp = _dt.datetime.now().isoformat(timespec="seconds")
        with log_path.open("a", encoding="utf-8") as fh:
            fh.write(f"[{stamp}] {message}\n")

    log(f"Updater started for target {args.version}; waiting for PID {args.pid}")
    deadline = time.time() + 45
    while _pid_running(args.pid) and time.time() < deadline:
        time.sleep(0.25)
    if _pid_running(args.pid):
        log("Timed out waiting for node process to exit; update aborted")
        return 2

    timestamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = updates / "backups" / timestamp
    backup.mkdir(parents=True, exist_ok=True)

    replaced = []
    try:
        manifest_path = staging / "update_manifest.json"
        if not manifest_path.exists():
            raise RuntimeError("Staged update manifest is missing")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        files = manifest.get("files") or []
        if not isinstance(files, list) or not files:
            raise RuntimeError("Staged update manifest contains no files")

        for rel in files:
            rel = str(rel).replace("\\", "/").strip("/")
            if rel not in ALLOWED_FILES:
                raise RuntimeError(f"Update attempted to replace disallowed file: {rel}")
            src = staging / rel
            if not src.is_file():
                raise RuntimeError(f"Staged file is missing: {rel}")
            dst = base / rel
            if dst.exists():
                backup_dst = backup / rel
                backup_dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, backup_dst)
            _copy_file(src, dst)
            replaced.append(rel)
            log(f"Applied {rel}")

        (updates / "last_update.json").write_text(
            json.dumps(
                {
                    "version": args.version,
                    "installed_at": _dt.datetime.now(_dt.timezone.utc).isoformat(),
                    "backup": str(backup),
                    "files": replaced,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
    except Exception as error:
        log(f"Update failed: {error}; attempting rollback")
        for rel in reversed(replaced):
            backup_src = backup / rel
            if backup_src.exists():
                try:
                    _copy_file(backup_src, base / rel)
                    log(f"Rolled back {rel}")
                except Exception as rollback_error:
                    log(f"Rollback failed for {rel}: {rollback_error}")
        return 3

    try:
        node_script = base / "tgc_invite_node.py"
        creationflags = 0
        if os.name == "nt":
            creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
        subprocess.Popen(
            [sys.executable, str(node_script)],
            cwd=str(base),
            close_fds=(os.name != "nt"),
            creationflags=creationflags,
        )
        log(f"Update to {args.version} completed and node restart launched")
    except Exception as error:
        log(f"Update installed but restart failed: {error}")
        return 4

    try:
        shutil.rmtree(staging, ignore_errors=True)
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
