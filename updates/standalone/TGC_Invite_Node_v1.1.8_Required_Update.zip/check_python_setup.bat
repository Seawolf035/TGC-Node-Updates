@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TGC Invite Node - Setup Check

echo ================================================================
echo  TGC Invite Node - Python Setup Check
 echo ================================================================
echo.

set "FOUND=0"

where py >nul 2>&1
if not errorlevel 1 (
    echo Python launcher found:
    py -3 -c "import sys; print('  Version: ' + sys.version.split()[0]); print('  Path:    ' + sys.executable)" 2>nul
    py -3 -c "import sys, tkinter, sqlite3, urllib.request, json; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
    if not errorlevel 1 (
        echo   Status:  READY
        set "FOUND=1"
    ) else (
        echo   Status:  NOT READY - Python is too old or Tkinter is missing
    )
    echo.
)

where python >nul 2>&1
if not errorlevel 1 (
    echo python.exe on PATH:
    python -c "import sys; print('  Version: ' + sys.version.split()[0]); print('  Path:    ' + sys.executable)" 2>nul
    python -c "import sys, tkinter, sqlite3, urllib.request, json; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
    if not errorlevel 1 (
        echo   Status:  READY
        set "FOUND=1"
    ) else (
        echo   Status:  NOT READY - Python is too old or Tkinter is missing
    )
    echo.
)

if "%FOUND%"=="1" (
    echo [OK] This computer is ready to run TGC Invite Node.
    echo      No pip packages are required.
) else (
    echo [NOT READY] Run run_node.bat for guided Python setup.
)

echo.
if exist "%~dp0tgc_invite_node.py" if exist "%~dp0tgc_vrchat_multilog.py" (
    echo [OK] Node program files are present in this extracted folder.
) else (
    echo [NOTE] Python setup can still be checked here, but the node files are
    echo        not visible beside this BAT file.
    echo        If you opened this BAT directly inside the ZIP, use Extract All
    echo        before running the node.
)

echo.
pause
endlocal
