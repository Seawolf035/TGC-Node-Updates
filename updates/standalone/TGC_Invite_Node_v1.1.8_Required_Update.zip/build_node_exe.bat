@echo off
cd /d "%~dp0"
py -3 -m pip install --upgrade pyinstaller
py -3 -m PyInstaller --noconfirm --onefile --windowed --name "TGC Invite Node" tgc_invite_node.py
echo.
echo Built EXE is in the dist folder.
pause
