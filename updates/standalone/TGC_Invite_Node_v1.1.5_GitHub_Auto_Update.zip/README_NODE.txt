TGC INVITE NODE v1.1.5 — GITHUB AUTO UPDATE
=====================================

This is the staff-facing half of the TGC Distributed Invite Network.
It DOES NOT log into VRChat and DOES NOT contain the central inviter account.

Requirements:
- Windows
- Python 3.8+ with Tkinter (standard Windows Python installer includes it)
- VRChat desktop client logs at the normal AppData/LocalLow location

Setup:
1. RIGHT-CLICK THE ZIP AND CHOOSE "EXTRACT ALL..." FIRST. Do not run the BAT files from inside the compressed ZIP.
2. Run run_node.bat (recommended) or tgc_invite_node.py.
3. Enter the Apps Script Web App URL provided by Seawolf.
4. Enter the unique Node ID and Node Key provided for this computer.
5. The Node Name is assigned centrally in the Apps Script Nodes sheet and is pulled automatically.
6. Save -> Test Relay -> Start Node. Test Relay will show the canonical name returned by the relay.

CENTRAL NODE NAME
-----------------
The Apps Script/Nodes sheet is authoritative for each node's display name.
The node no longer sends a local name back to the relay, so a staff PC cannot
accidentally overwrite the central label. On startup and Test Relay, the node
requests node_status, caches the returned node_name locally, and displays it in
the GUI/title bar. If Seawolf changes the name in Apps Script, press Test Relay
or restart the node to refresh it.

MULTI-INSTANCE BEHAVIOR
-----------------------
One node watches ALL actively-growing VRChat output_log_*.txt files on the PC.
You do not need to run one node per VRChat client.

The watcher:
- discovers new VRChat logs automatically while the node is running;
- tails every active log independently;
- scans the current instance of each fresh log when first discovered;
- tracks join/leave state separately per log;
- retires a log after it has been inactive for 15 minutes;
- rediscovers it automatically if it begins growing again;
- merges all sightings into one local queue;
- locally deduplicates the same usr_... across every VRChat client.

The GUI shows the number of active VRChat instances and total tracked players
across those active logs.

QUEUE / RELAY BEHAVIOR
----------------------
- New OnPlayerJoined entries are recorded locally in node_queue.db.
- Repeated sightings of the same user within the Local Repeat Dedupe window are
  not re-uploaded (default: 60 minutes), even if seen in another VRChat client.
- Sightings are uploaded in batches every 60 seconds by default.
- If Google/the internet is unavailable, pending events remain in SQLite and are
  retried later, including after reboot/restart.

Revocation:
If your Node ID is disabled centrally, uploads immediately begin returning a
revoked/disabled error. No other node keys are affected.

PYTHON DETECTOR / SETUP LAUNCHER
--------------------------------
Use run_node.bat instead of launching the .py file directly. It:
- detects Python 3.8+ via py, PATH, or normal per-user install paths;
- verifies Tkinter and required standard-library modules;
- requires no pip packages for normal operation;
- can install Python through winget if Python is missing;
- falls back to the official Python Windows download page;
- installs/checks Python first, then verifies both node Python files before launch;
- detects the common "BAT launched directly inside ZIP" case and tells you to Extract All instead of reporting a misleading setup failure.

check_python_setup.bat is a non-installing Python readiness check. It no longer fails just because Windows launched it from a compressed-folder temp location.

Optional EXE:
Run build_node_exe.bat to install PyInstaller and create a standalone Windows EXE.
The local tgc_vrchat_multilog.py module is included automatically by PyInstaller.


DISCORD NODE LINKING
--------------------
The relay is the authority for the Node ID and Node Name. To securely bind this
physical node to the staff member's Discord account:

1. Make sure Relay URL, Node ID, and Node Key are configured.
2. Click "Link Discord" in the node app.
3. The relay creates a one-time code such as TGC-NODE-1A2B3C4D.
4. The code is copied to the clipboard and expires after 10 minutes.
5. In the TGC Discord, the staff member runs:
       /verifynode code:TGC-NODE-1A2B3C4D
6. The central launcher verifies the code through the relay and binds that Node ID
   to the clicking Discord user's current TGC roster entry.

The code is single-use. Generating a new code replaces the previous unused code.
An owner can still use the launcher's Node Attribution tab as an explicit owner
override if needed.


ONE-CLICK UPDATES
-----------------
This build can update itself without staff downloading/extracting a replacement ZIP.

On startup the node reads the current standalone release from the public
Seawolf035/TGC-Node-Updates GitHub manifest. Staff can also press "Check for Updates".
When a newer release exists, "Install Update" will:
- download the exact ZIP from the GitHub manifest URL;
- verify its SHA-256 before opening/installing it;
- reject unsafe ZIP paths or an unexpected package layout;
- preserve node_config.json, Node ID/Node Key, node_queue.db and SQLite WAL/SHM;
- back up the current program files under updates/backups/;
- close the node, apply the update through tgc_node_update_helper.py;
- restart the node automatically;
- roll back changed program files if applying the update fails.

Release policies:
- optional: update is available but does not interrupt uploads;
- recommended: update is prominently marked but uploads continue;
- required: the node keeps watching/buffering locally, but sighting uploads pause
  until the required update is installed. No sightings are discarded.

The automatic updater is designed for the normal Python/run_node.bat distribution.
The exact release ZIP must be the same file whose SHA-256 was published by the
central launcher / Apps Script relay.
