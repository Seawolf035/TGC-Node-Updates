@echo off
setlocal
cd /d "%~dp0"
title TGC Staff Launcher Installer

echo =============================================
echo       TGC Staff Launcher Installer
echo =============================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo Python was not found.
    echo.
    echo Install Python 3.11 or newer from python.org.
    echo IMPORTANT: Check "Add Python to PATH" during installation.
    echo Then run this installer again.
    pause
    exit /b 1
)

py -m pip install --upgrade pip
if errorlevel 1 goto :fail
py -m pip install -r requirements.txt
if errorlevel 1 goto :fail

echo.
echo Installation complete.
echo Use Run_TGC_Staff_Launcher.bat to start it.
pause
exit /b 0

:fail
echo.
echo Installation failed. Copy the error above and send it to Seawolf.
pause
exit /b 1
