@echo off
cd /d "%~dp0"
py TGC_Staff_Launcher.py
pause
