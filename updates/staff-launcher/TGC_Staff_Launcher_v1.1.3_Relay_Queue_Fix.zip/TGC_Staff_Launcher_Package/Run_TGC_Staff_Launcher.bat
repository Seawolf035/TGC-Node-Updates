@echo off
cd /d "%~dp0"
pyw TGC_Staff_Launcher.py
if errorlevel 1 (
    echo The launcher failed to start.
    echo Run Install_TGC_Staff_Launcher.bat first.
    pause
)
