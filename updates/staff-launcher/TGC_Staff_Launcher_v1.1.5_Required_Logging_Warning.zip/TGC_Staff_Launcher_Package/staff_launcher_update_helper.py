#!/usr/bin/env python3
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

ALLOWED_FILES = (
    "TGC_Staff_Launcher.py",
    "tgc_staff_node.py",
    "tgc_vrchat_multilog.py",
    "staff_launcher_update_helper.py",
    "README_FIRST.txt",
    "requirements.txt",
    "Run_TGC_Staff_Launcher.bat",
    "Run_TGC_Staff_Launcher_Debug.bat",
    "Install_TGC_Staff_Launcher.bat",
    "V1_1_VERIFIED_NODE_UPDATE.txt",
    "V1_1_1_GITHUB_UPDATER.txt",
)

PRESERVED_NAMES = (
    "tgc_staff_launcher_config.json",
    "tgc_staff_node_config.json",
    "tgc_staff_node_key.dpapi",
    "tgc_staff_node_queue.db",
    "tgc_staff_node_queue.db-wal",
    "tgc_staff_node_queue.db-shm",
)


def pid_exists(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            SYNCHRONIZE = 0x00100000
            handle = ctypes.windll.kernel32.OpenProcess(SYNCHRONIZE, False, int(pid))
            if not handle:
                return False
            try:
                result = ctypes.windll.kernel32.WaitForSingleObject(handle, 0)
                return result == 0x00000102
            finally:
                ctypes.windll.kernel32.CloseHandle(handle)
        except Exception:
            return True
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def wait_for_exit(pid: int, timeout=120):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not pid_exists(pid):
            return
        time.sleep(0.25)
    raise RuntimeError(f"Staff Launcher PID {pid} did not exit within {timeout} seconds.")


def atomic_copy(source: Path, target: Path):
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + ".update-new")
    shutil.copy2(source, tmp)
    os.replace(tmp, target)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pid", type=int, required=True)
    ap.add_argument("--source", required=True)
    ap.add_argument("--target", required=True)
    ap.add_argument("--restart", required=True)
    ap.add_argument("--version", required=True)
    args = ap.parse_args()

    source = Path(args.source).resolve()
    target = Path(args.target).resolve()
    restart = Path(args.restart).resolve()
    update_root = target / "staff_launcher_updates"
    backup_root = update_root / "backups" / datetime.now().strftime("%Y%m%d_%H%M%S")
    update_root.mkdir(parents=True, exist_ok=True)
    log_path = update_root / "update.log"

    def log(message):
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with log_path.open("a", encoding="utf-8") as fh:
            fh.write(f"[{stamp}] {message}\n")

    replaced = []
    existed = {}
    try:
        if not (source / "TGC_Staff_Launcher.py").is_file():
            raise RuntimeError("Staged update source does not contain TGC_Staff_Launcher.py")
        wait_for_exit(args.pid)
        backup_root.mkdir(parents=True, exist_ok=True)
        log(f"Installing Staff Launcher v{args.version} from {source}")

        for name in ALLOWED_FILES:
            src = source / name
            if not src.is_file():
                continue
            dst = target / name
            existed[name] = dst.exists()
            if dst.exists():
                shutil.copy2(dst, backup_root / name)
            atomic_copy(src, dst)
            replaced.append(name)

        if "TGC_Staff_Launcher.py" not in replaced or "tgc_staff_node.py" not in replaced or "tgc_vrchat_multilog.py" not in replaced:
            raise RuntimeError("Required Staff Launcher runtime files were not replaced.")

        metadata = {
            "installed_version": args.version,
            "installed_at": datetime.now().isoformat(timespec="seconds"),
            "backup": str(backup_root),
            "replaced_files": replaced,
            "preserved_files": [name for name in PRESERVED_NAMES if (target / name).exists()],
        }
        (update_root / "last_update.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        log(f"Update installed successfully; replaced {len(replaced)} file(s).")
    except Exception as exc:
        log(f"Update failed: {exc}; attempting rollback.")
        for name in reversed(replaced):
            dst = target / name
            old = backup_root / name
            try:
                if old.is_file():
                    atomic_copy(old, dst)
                elif not existed.get(name, False):
                    dst.unlink(missing_ok=True)
            except Exception as rollback_exc:
                log(f"Rollback failed for {name}: {rollback_exc}")
        log("Rollback attempt complete.")
        raise

    try:
        creationflags = 0
        if os.name == "nt":
            creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
        subprocess.Popen(
            [sys.executable, str(restart)],
            cwd=str(target),
            close_fds=(os.name != "nt"),
            creationflags=creationflags,
        )
        log("Restarted updated Staff Launcher.")
    except Exception as exc:
        log(f"Update installed, but automatic restart failed: {exc}")


if __name__ == "__main__":
    main()
