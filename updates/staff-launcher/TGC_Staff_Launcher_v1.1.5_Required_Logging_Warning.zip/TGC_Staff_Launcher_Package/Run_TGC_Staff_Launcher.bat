@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
    echo Staff Launcher dependencies are not installed.
    echo Run Install_TGC_Staff_Launcher.bat first.
    pause
    exit /b 1
)
start "" ".venv\Scripts\pythonw.exe" "TGC_Staff_Launcher.py"
