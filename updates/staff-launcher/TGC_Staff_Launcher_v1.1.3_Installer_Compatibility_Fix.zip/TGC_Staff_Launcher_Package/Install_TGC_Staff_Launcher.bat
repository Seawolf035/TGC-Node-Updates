@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TGC Staff Launcher Installer
echo =============================================
echo       TGC Staff Launcher Installer
echo =============================================
echo.
where py >nul 2>nul
if errorlevel 1 goto :no_python
set "SELECTED="
for %%V in (3.13 3.12 3.11 3.14) do (
    if not defined SELECTED (
        py -%%V -c "import sys; assert sys.version_info[:2] == tuple(map(int, '%%V'.split('.'))) and getattr(sys, '_is_gil_enabled', lambda: True)()" >nul 2>nul
        if not errorlevel 1 set "SELECTED=%%V"
    )
)
if not defined SELECTED goto :no_compatible_python
echo Using Python %SELECTED% for this installation.
echo.
if not exist ".venv\Scripts\python.exe" (
    py -%SELECTED% -m venv ".venv"
    if errorlevel 1 goto :fail
)
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -c "import psutil, win32api; print('Dependencies verified.')"
if errorlevel 1 goto :fail
echo.
echo Installation complete.
echo Use Run_TGC_Staff_Launcher.bat to start it.
pause
exit /b 0
:no_python
echo Python Launcher 'py' was not found.
echo Install Python 3.13 from https://www.python.org/downloads/
pause
exit /b 1
:no_compatible_python
echo A supported regular CPython installation was not found.
echo Recommended: install Python 3.13 from https://www.python.org/downloads/
pause
exit /b 1
:fail
echo.
echo Installation failed. Copy the error above and send it to Seawolf.
echo If you switched Python versions, remove the .venv folder and retry.
pause
exit /b 1
