TGC STAFF LAUNCHER v1.1.0
=========================

PURPOSE
-------
This is the verified limited staff edition of the TGC VRChat instance launcher.
It can run a maximum of three local VRChat instances and includes the OSC
repeater, avatar scale/eye-height controls, smooth scaling, pulse controls, and
an embedded TGC Invite Node.

VERIFICATION IS REQUIRED
------------------------
The launcher does not expose its VRChat/OSC controls until TGC verification
succeeds. There is no manual Node ID / Node Key bypass.

A TGC owner must create a deployment from the main launcher's:
Invite Network -> Deploy Nodes

The deployment type MUST be:
staff_launcher

Send the staff member the full one-time setup link. On first launch they paste
that link into the verification window and click Deploy & Verify.

After successful deployment:
- the launcher unlocks for the verified staff account;
- the embedded Invite Node starts automatically;
- the node watches all active VRChat output logs on that PC;
- its Node Key is protected using Windows DPAPI;
- the relay sees node version 1.1.6-staff and client type staff_launcher.

The launcher re-checks verification while it is running. If the node is revoked,
disabled, invalid, or no longer verifies as a Staff Launcher deployment, the
launcher locks again.

FIRST-TIME SETUP
----------------
1. Extract the entire ZIP to a normal folder.
2. Install Python 3.11 or newer from python.org if it is not installed.
   During Python setup, check "Add Python to PATH".
3. Double-click Install_TGC_Staff_Launcher.bat.
4. Double-click Run_TGC_Staff_Launcher.bat.
5. Paste the full owner-issued staff_launcher deployment link.
6. Click Deploy & Verify.
7. After verification, open Settings and confirm the VRChat launch.exe path.

DEFAULT VRCHAT PATH
-------------------
C:\Program Files (x86)\Steam\steamapps\common\VRChat\launch.exe

INSTANCE PORTS
--------------
Instance 1: OSC input 9001, output 9101
Instance 2: OSC input 9002, output 9102
Instance 3: OSC input 9003, output 9103
Repeater input: 9000

The launcher always remains hard-limited to three local instances.

TROUBLESHOOTING
---------------
- If verification fails, use Retry/Verify Existing Installation and confirm the
  central relay is online.
- If the deployment link is rejected, have an owner issue a new staff_launcher
  deployment link; standalone/plugin deployment links are intentionally refused.
- If the normal Run file closes immediately, use Run_TGC_Staff_Launcher_Debug.bat
  and copy the displayed error.
- If VRChat does not launch, select the correct launch.exe under Settings.
- If OSC does not affect every instance, start the OSC Repeater.
- Do not run another program that is already using UDP port 9000.

GITHUB SELF-UPDATES (v1.1.1+)
----------------------------
After this Staff Launcher verifies with TGC, it automatically checks the
staff_launcher channel in Seawolf035/TGC-Node-Updates. Use the Updates tab to
install a newer release. Updating preserves this PC's verification, DPAPI node
key, node queue, and launcher settings.
