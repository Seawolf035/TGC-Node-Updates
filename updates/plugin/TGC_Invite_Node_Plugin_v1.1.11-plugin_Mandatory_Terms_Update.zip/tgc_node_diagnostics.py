"""Legacy update ZIP compatibility marker: read-only Node diagnostic
logic is embedded in distributed_invite_node.py. No runtime imports."""
