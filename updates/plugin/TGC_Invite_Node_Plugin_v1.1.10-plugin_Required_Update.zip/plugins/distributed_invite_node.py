import hashlib
import json
import os
import queue
import shutil
import sqlite3
import tempfile
import threading
import urllib.request
import urllib.parse
import uuid
import zipfile
from datetime import datetime, timezone
import tkinter as tk
from tkinter import ttk, messagebox

from plugin_manager import Plugin
from tgc_vrchat_multilog import MultiVRChatLogWatcher

NODE_VERSION = "1.1.10-plugin"
HOTFIX_REVISION = 0
CLIENT_TYPE = "plugin"
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/Seawolf035/TGC-Node-Updates/main/manifest.json"
MAX_UPDATE_DOWNLOAD_BYTES = 100 * 1024 * 1024




# Integrated diagnostic: compatible with fixed-file legacy updaters.
#!/usr/bin/env python3
"""TGC Node v1.1.9 read-only, privacy-safe VRChat tracking report."""
import os
from pathlib import Path
import re
import time
from datetime import datetime

DIAG_JOIN_RE = re.compile(r"OnPlayerJoined\s+(.+?)\s+\((usr_[0-9a-fA-F-]{36})\)")
DIAG_LEAVE_RE = re.compile(r"OnPlayerLeft\s+(.+?)\s+\((usr_[0-9a-fA-F-]{36})\)")
DIAG_TAIL_BYTES = 12 * 1024 * 1024


def _diagnostic_inspect_log(path, now):
    stat = path.stat()
    size = stat.st_size
    item = dict(size=size, age_s=max(0, int(now - stat.st_mtime)),
                joins=0, joins_after_room=0, unmatched=0,
                leaves=0, transitions=0, truncated=size > DIAG_TAIL_BYTES)
    with path.open("rb") as f:
        if item["truncated"]:
            f.seek(-DIAG_TAIL_BYTES, os.SEEK_END)
            f.readline()
        lines = f.read().decode("utf-8", errors="replace").splitlines()
    latest_room = 0
    for i, line in enumerate(lines):
        if "Joining" in line and "Room" in line:
            latest_room = i
            item["transitions"] += 1
        if "OnPlayerJoined" in line:
            if DIAG_JOIN_RE.search(line):
                item["joins"] += 1
            else:
                item["unmatched"] += 1
        if DIAG_LEAVE_RE.search(line):
            item["leaves"] += 1
    item["joins_after_room"] = sum(bool(DIAG_JOIN_RE.search(line)) for line in lines[latest_room:])
    return item


def run_tracking_diagnostic(log_dir=None, output_dir=None, sample_seconds=10,
                            watcher_snapshot=None, session_stats=None):
    """Sample log files without stopping the live Node, then export counts only."""
    log_path = Path(log_dir) if log_dir else Path.home() / "AppData" / "LocalLow" / "VRChat" / "VRChat"
    destination = Path(output_dir) if output_dir else Path.home() / "Downloads"
    if not destination.is_dir():
        destination = Path.home()
    seconds = max(0, min(45, int(sample_seconds)))
    report = [
        "TGC Invite Node — VRChat Tracking Diagnostic",
        f'Generated: {datetime.now().astimezone().isoformat(timespec="seconds")}',
        "Read-only. Contains no player names, user IDs, log text, or Node credentials.",
        "This report is not uploaded automatically.",
        "",
        f"VRChat log directory found: {log_path.is_dir()}",
    ]
    if isinstance(watcher_snapshot, dict):
        report.extend([
            "Live watcher status:",
            f'  Running: {bool(watcher_snapshot.get("running"))}',
            f'  Active logs: {int(watcher_snapshot.get("active_logs") or 0)}',
            f'  Tracked logs: {int(watcher_snapshot.get("tracked_logs") or 0)}',
            f'  Tracked players: {int(watcher_snapshot.get("active_players") or 0)}',
        ])
    if isinstance(session_stats, dict):
        report.extend([
            "Current session (counts only):",
            f'  Seen: {int(session_stats.get("seen") or 0)}',
            f'  New: {int(session_stats.get("new") or 0)}',
            f'  Local duplicates: {int(session_stats.get("duplicates") or 0)}',
            f'  Pending uploads: {int(session_stats.get("pending") or 0)}',
        ])
    recent = []
    selected = []
    inspected = {}
    failures = 0
    if log_path.is_dir():
        try:
            logs = sorted(log_path.glob("output_log_*.txt"), key=lambda x: x.stat().st_mtime, reverse=True)
        except OSError as exc:
            logs = []
            failures += 1
            report.append(f"Cannot list VRChat logs: {type(exc).__name__}; details omitted.")
        report.append(f"Logs found: {len(logs)}")
        now = time.time()
        for path in logs:
            try:
                if now - path.stat().st_mtime <= 900:
                    recent.append(path)
            except OSError:
                failures += 1
        report.append(f"Logs modified within 15 minutes: {len(recent)}")
        selected = logs[:5]
        for i, path in enumerate(selected, 1):
            try:
                item = _diagnostic_inspect_log(path, now)
                inspected[path] = item
                report.extend([
                    f'Log #{i}: size {item["size"]} bytes; last modified {item["age_s"]}s ago',
                    f'  Recent enough: {item["age_s"] <= 900}',
                    f'  Recognized joins: {item["joins"]}; after last room: {item["joins_after_room"]}',
                    f'  Unrecognized join lines: {item["unmatched"]}; leaves: {item["leaves"]}',
                    f'  Room entries: {item["transitions"]}; tail limited to 12MiB: {item["truncated"]}',
                ])
            except (OSError, UnicodeError, ValueError) as exc:
                failures += 1
                report.append(f"Log #{i}: READ ERROR {type(exc).__name__}; details omitted.")
    if log_path.is_dir() and selected and seconds:
        report.append(f"Watching for appended logs for {seconds}s without pausing Node.")
        time.sleep(seconds)
    growth = 0
    new_joins = 0
    for i, path in enumerate(selected, 1):
        if path not in inspected:
            continue
        try:
            item = _diagnostic_inspect_log(path, time.time())
            previous = inspected[path]
            delta = max(0, item["size"] - previous["size"])
            join_delta = max(0, item["joins"] - previous["joins"])
            growth += delta
            new_joins += join_delta
            report.append(f"Log #{i} during sample: +{delta} bytes, +{join_delta} joins")
        except (OSError, UnicodeError, ValueError) as exc:
            failures += 1
            report.append(f"Log #{i}: SECOND READ ERROR {type(exc).__name__}; details omitted.")

    if not log_path.is_dir():
        diagnosis = "VRChat logs were not found for this Windows profile."
    elif failures:
        diagnosis = "Log access errors; check file permissions and access."
    elif not recent:
        diagnosis = "No recently updated VRChat logs; check running VRChat and Windows profile."
    elif any(item["unmatched"] for item in inspected.values()):
        diagnosis = "Unrecognized OnPlayerJoined lines; the watcher parser may need updating."
    elif not any(item["joins"] for item in inspected.values()):
        diagnosis = "No OnPlayerJoined entries detected; join a populated instance and try again."
    elif isinstance(watcher_snapshot, dict) and int(watcher_snapshot.get("active_players") or 0) == 0:
        diagnosis = "VRChat join entries found, but live watcher tracks zero players. Investigate watcher/callback."
    elif not growth:
        diagnosis = "Join entries present but no new log activity during sample."
    else:
        diagnosis = "VRChat log activity present; compare Seen/New counters for callback behavior."
    report.extend(["", f"Appended: {growth} bytes; new joins: {new_joins}",
                   f"DIAGNOSIS: {diagnosis}",
                   "This diagnostic does not alter tracking, queues, log files, or credentials."])
    output = destination / ("TGC_Node_Tracking_Diagnostic_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".txt")
    output.write_text("\n".join(report) + "\n", encoding="utf-8")
    return str(output), diagnosis


class NodeLocalStore:
    """Crash-safe local buffer for sightings waiting to reach the relay."""

    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()
        self._init()

    def _con(self):
        connection = sqlite3.connect(self.path, timeout=30)
        connection.row_factory = sqlite3.Row
        return connection

    def _init(self):
        with self._con() as connection:
            connection.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS sightings (
                    event_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    display_name TEXT,
                    seen_at TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_sightings_status
                    ON sightings(status, created_at);

                CREATE TABLE IF NOT EXISTS recent_users (
                    user_id TEXT PRIMARY KEY,
                    last_seen_at TEXT NOT NULL
                );
                """
            )

    def add_sighting(self, user_id, display_name, seen_at, dedupe_minutes=60):
        now = datetime.now(timezone.utc)
        with self.lock, self._con() as connection:
            row = connection.execute(
                "SELECT last_seen_at FROM recent_users WHERE user_id=?",
                (user_id,),
            ).fetchone()
            if row:
                try:
                    last = datetime.fromisoformat(
                        str(row["last_seen_at"]).replace("Z", "+00:00")
                    )
                    if (now - last).total_seconds() < max(0, int(dedupe_minutes)) * 60:
                        connection.execute(
                            "UPDATE recent_users SET last_seen_at=? WHERE user_id=?",
                            (now.isoformat(), user_id),
                        )
                        return False, None
                except Exception:
                    pass

            event_id = "evt_" + uuid.uuid4().hex
            connection.execute(
                """
                INSERT INTO sightings(
                    event_id, user_id, display_name, seen_at, created_at, status
                ) VALUES(?,?,?,?,?, 'pending')
                """,
                (
                    event_id,
                    user_id,
                    display_name,
                    seen_at,
                    now.isoformat(),
                ),
            )
            connection.execute(
                """
                INSERT INTO recent_users(user_id,last_seen_at)
                VALUES(?,?)
                ON CONFLICT(user_id) DO UPDATE SET
                    last_seen_at=excluded.last_seen_at
                """,
                (user_id, now.isoformat()),
            )
            return True, event_id

    def pending(self, limit=100):
        limit = max(1, min(250, int(limit)))
        with self.lock, self._con() as connection:
            rows = connection.execute(
                """
                SELECT * FROM sightings
                WHERE status='pending'
                ORDER BY created_at ASC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
            return [dict(row) for row in rows]

    def mark_submitted(self, event_ids):
        if not event_ids:
            return
        with self.lock, self._con() as connection:
            connection.executemany(
                """
                UPDATE sightings
                SET status='submitted', last_error=NULL
                WHERE event_id=?
                """,
                [(event_id,) for event_id in event_ids],
            )

    def mark_attempt_error(self, event_ids, error):
        if not event_ids:
            return
        text = str(error)[:1000]
        with self.lock, self._con() as connection:
            connection.executemany(
                """
                UPDATE sightings
                SET attempts=attempts+1, last_error=?
                WHERE event_id=?
                """,
                [(text, event_id) for event_id in event_ids],
            )

    def counts(self):
        with self.lock, self._con() as connection:
            pending = connection.execute(
                "SELECT COUNT(*) FROM sightings WHERE status='pending'"
            ).fetchone()[0]
            submitted = connection.execute(
                "SELECT COUNT(*) FROM sightings WHERE status='submitted'"
            ).fetchone()[0]
            total = connection.execute(
                "SELECT COUNT(*) FROM sightings"
            ).fetchone()[0]
            return int(total), int(pending), int(submitted)


class DistributedInviteNodePlugin(Plugin):
    """Optional multi-instance collector for the TGC distributed invite network."""

    def __init__(self, app=None):
        super().__init__(app)
        self.name = "Distributed Invite Node"
        self.version = "1.4.0"
        self.description = (
            "Optionally turn this PC into a TGC invite-network node. Watches every "
            "active VRChat output log, locally deduplicates/buffers sightings, and "
            "sends them to the Google Apps Script relay using a revocable Node key. "
            "It never uses or transmits this app's VRChat login/session."
        )
        self.author = "Seawolf / The Gamer Club"

        self.tab = None
        self.start_btn = None
        self.stop_btn = None
        self.recent_text = None
        self.shutting_down = False
        self.refresh_job = None
        self.sync_stop = threading.Event()
        self.sync_thread = None
        self.sync_lock = threading.Lock()
        self.recent_messages = queue.Queue()
        self.release_info = {}
        self.update_required = False
        self.update_in_progress = False
        self.update_notice_shown_for = ""

        self.session_seen = 0
        self.session_new = 0
        self.session_duplicates = 0
        self.session_submitted = 0

        root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.root_dir = root_dir
        self.settings_path = os.path.join(root_dir, "invite_node_settings.json")
        self.db_path = os.path.join(root_dir, "invite_node_queue.db")
        self.store = NodeLocalStore(self.db_path)
        self.settings = self._load_settings()

        self.watcher = MultiVRChatLogWatcher(
            self._on_join,
            self._on_watcher_status,
        )

    def get_info(self):
        info = super().get_info()
        info["actions"] = [
            "Watch every active VRChat instance on this PC",
            "Buffer sightings locally while offline",
            "Submit sightings through the Google Apps Script relay",
            "Use one-time owner-issued deployment links for setup",
            "Use a unique revocable Node ID / encrypted Node Key",
            "Run privacy-safe tracking diagnostics directly from the Node tab",
            "Run independently of the normal inviter and Invite Recycler",
        ]
        return info

    def initialize(self):
        if self.app is not None and hasattr(self.app, "notebook"):
            self.create_tab(self.app.notebook)
            if bool(self.settings.get("auto_start", False)):
                try:
                    self.app.root.after(800, self.start_node)
                except Exception:
                    pass
            if self.settings.get("relay_url") and self.settings.get("node_id") and self.settings.get("node_key_runtime"):
                try:
                    self.app.root.after(1400, lambda: self.check_for_updates(silent=True))
                except Exception:
                    pass

    def shutdown(self):
        self.shutting_down = True
        self.stop_node()
        try:
            self._save_from_ui(silent=True)
        except Exception:
            pass
        if self.refresh_job is not None:
            try:
                self.app.root.after_cancel(self.refresh_job)
            except Exception:
                pass
            self.refresh_job = None

    # ------------------------------------------------------------------
    # Settings / secure Node key
    # ------------------------------------------------------------------
    def _default_settings(self):
        return {
            "version": 1,
            "relay_url": "",
            "node_id": "",
            "node_name": "",
            "install_id": "",
            "sync_interval_seconds": 60,
            "batch_size": 100,
            "local_dedupe_minutes": 60,
            "auto_start": False,
            "ignore_user_ids": [],
        }

    def _config_manager(self):
        try:
            return self.app.logic.config_manager
        except Exception:
            return None

    def _encrypt_key(self, value):
        value = str(value or "")
        if not value:
            return ""
        manager = self._config_manager()
        if manager and hasattr(manager, "_encrypt_text"):
            return manager._encrypt_text(value)
        # Do not silently write a raw Node key if secure storage is unavailable.
        raise RuntimeError("Secure configuration storage is unavailable.")

    def _decrypt_key(self, value):
        value = str(value or "")
        if not value:
            return ""
        manager = self._config_manager()
        if manager and hasattr(manager, "_decrypt_text"):
            return manager._decrypt_text(value)
        return ""

    def _load_settings(self):
        settings = self._default_settings()
        try:
            if os.path.exists(self.settings_path):
                with open(self.settings_path, "r", encoding="utf-8") as file:
                    loaded = json.load(file)
                if isinstance(loaded, dict):
                    settings.update(loaded)
        except Exception as error:
            self._log(f"Invite Node: could not load settings: {error}")

        # The raw key is never intentionally stored in invite_node_settings.json.
        encrypted = settings.pop("node_key_encrypted", "") or ""
        plaintext_legacy = settings.pop("node_key", "") or ""
        try:
            if encrypted:
                settings["node_key_runtime"] = self._decrypt_key(encrypted)
            elif plaintext_legacy:
                # Migrate an accidental/legacy plaintext setting on next save.
                settings["node_key_runtime"] = plaintext_legacy
            else:
                settings["node_key_runtime"] = ""
        except Exception as error:
            settings["node_key_runtime"] = ""
            self._log(f"Invite Node: could not decrypt saved Node key: {error}")
        if not str(settings.get("install_id") or "").strip():
            settings["install_id"] = uuid.uuid4().hex
        return settings

    def _save_settings(self):
        payload = dict(self.settings)
        raw_key = str(payload.pop("node_key_runtime", "") or "")
        payload.pop("node_key", None)
        payload["node_key_encrypted"] = self._encrypt_key(raw_key) if raw_key else ""
        tmp = self.settings_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as file:
            json.dump(payload, file, indent=2)
        os.replace(tmp, self.settings_path)

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def create_tab(self, notebook):
        if self.tab is not None:
            return

        self.tab = ttk.Frame(notebook)
        notebook.add(self.tab, text="Invite Node")

        container = ttk.Frame(self.tab)
        container.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)

        ttk.Label(
            container,
            text="TGC Distributed Invite Node",
            font=("Segoe UI", 16, "bold"),
        ).pack(anchor=tk.W)
        ttk.Label(
            container,
            text=(
                "Optional mode: watch every active VRChat instance on this PC and "
                "send encountered user IDs to the TGC Google relay. This does not "
                "use the VRChat account logged into the inviter and can run at the "
                "same time as the normal inviter or Invite Recycler."
            ),
            wraplength=900,
            justify=tk.LEFT,
        ).pack(anchor=tk.W, pady=(2, 10))

        deploy_frame = ttk.LabelFrame(container, text="Quick Deployment")
        deploy_frame.pack(fill=tk.X, pady=(0, 10))
        deploy_frame.columnconfigure(0, weight=1)
        ttk.Label(
            deploy_frame,
            text=(
                "Paste the one-time deployment link from a TGC owner. The link carries "
                "the relay address, and the plugin securely stores the issued Node Key "
                "through Auto Invite's encrypted configuration manager."
            ),
            wraplength=900,
            justify=tk.LEFT,
        ).grid(row=0, column=0, columnspan=2, sticky=tk.W, padx=6, pady=(5, 3))
        self.deploy_var = tk.StringVar()
        ttk.Entry(deploy_frame, textvariable=self.deploy_var).grid(
            row=1, column=0, sticky=tk.EW, padx=6, pady=(3, 6)
        )
        ttk.Button(
            deploy_frame,
            text="Deploy This Node",
            command=self.redeem_deployment,
        ).grid(row=1, column=1, sticky=tk.E, padx=6, pady=(3, 6))

        settings_frame = ttk.LabelFrame(container, text="Node Preferences")
        settings_frame.pack(fill=tk.X, pady=(0, 10))
        settings_frame.columnconfigure(1, weight=1)

        self.relay_url_var = tk.StringVar(value=self.settings.get("relay_url", ""))
        self.node_id_var = tk.StringVar(value=self.settings.get("node_id", ""))
        self.node_key_var = tk.StringVar(value=self.settings.get("node_key_runtime", ""))
        self.node_name_var = tk.StringVar(value=self.settings.get("node_name", ""))
        self.sync_interval_var = tk.IntVar(
            value=int(self.settings.get("sync_interval_seconds", 60))
        )
        self.batch_size_var = tk.IntVar(value=int(self.settings.get("batch_size", 100)))
        self.dedupe_var = tk.IntVar(
            value=int(self.settings.get("local_dedupe_minutes", 60))
        )
        self.auto_start_var = tk.BooleanVar(value=bool(self.settings.get("auto_start", False)))

        ttk.Label(settings_frame, text="Node:").grid(row=0, column=0, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings_frame, textvariable=self.node_name_var).grid(row=0, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings_frame, text="Enrollment is managed exclusively through Quick Deployment.", wraplength=820).grid(row=1, column=0, columnspan=4, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings_frame, text="Sync Interval:").grid(
            row=4, column=0, sticky=tk.W, padx=6, pady=4
        )
        ttk.Spinbox(
            settings_frame,
            from_=15,
            to=3600,
            increment=15,
            textvariable=self.sync_interval_var,
            width=10,
        ).grid(row=4, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings_frame, text="seconds").grid(row=4, column=2, sticky=tk.W)

        ttk.Label(settings_frame, text="Upload Batch Size:").grid(
            row=5, column=0, sticky=tk.W, padx=6, pady=4
        )
        ttk.Spinbox(
            settings_frame,
            from_=1,
            to=250,
            textvariable=self.batch_size_var,
            width=10,
        ).grid(row=5, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings_frame, text="sightings (max 250)").grid(
            row=5, column=2, sticky=tk.W
        )

        ttk.Label(settings_frame, text="Local Repeat Dedupe:").grid(
            row=6, column=0, sticky=tk.W, padx=6, pady=4
        )
        ttk.Spinbox(
            settings_frame,
            from_=0,
            to=10080,
            textvariable=self.dedupe_var,
            width=10,
        ).grid(row=6, column=1, sticky=tk.W, padx=6, pady=4)
        ttk.Label(settings_frame, text="minutes").grid(row=6, column=2, sticky=tk.W)

        ttk.Checkbutton(
            settings_frame,
            text="Automatically start Node when the app opens",
            variable=self.auto_start_var,
        ).grid(row=7, column=0, columnspan=4, sticky=tk.W, padx=6, pady=4)

        settings_buttons = ttk.Frame(settings_frame)
        settings_buttons.grid(row=8, column=0, columnspan=4, sticky=tk.W, padx=6, pady=6)
        ttk.Button(
            settings_buttons,
            text="Save",
            command=self.save_from_ui,
        ).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(
            settings_buttons,
            text="Test Relay",
            command=self.test_relay,
        ).pack(side=tk.LEFT, padx=5)
        ttk.Button(
            settings_buttons,
            text="Sync Now",
            command=self.sync_now,
        ).pack(side=tk.LEFT, padx=5)

        updates_frame = ttk.LabelFrame(container, text="Node Plugin Updates")
        updates_frame.pack(fill=tk.X, pady=(0, 10))
        updates_frame.columnconfigure(0, weight=1)
        self.update_status_var = tk.StringVar(
            value=f"Installed: {NODE_VERSION} — update status not checked"
        )
        ttk.Label(
            updates_frame,
            textvariable=self.update_status_var,
            wraplength=730,
            justify=tk.LEFT,
        ).grid(row=0, column=0, sticky=tk.W, padx=6, pady=5)
        update_buttons = ttk.Frame(updates_frame)
        update_buttons.grid(row=0, column=1, sticky=tk.E, padx=6, pady=5)
        ttk.Button(
            update_buttons,
            text="Check for Updates",
            command=self.check_for_updates,
        ).pack(side=tk.LEFT, padx=(0, 5))
        self.install_update_btn = ttk.Button(
            update_buttons,
            text="Install Update",
            command=self.install_update,
            state=tk.DISABLED,
        )
        self.install_update_btn.pack(side=tk.LEFT)

        status_frame = ttk.LabelFrame(container, text="Node Status")
        status_frame.pack(fill=tk.X, pady=(0, 10))
        status_frame.columnconfigure(1, weight=1)

        self.watcher_status_var = tk.StringVar(value="Stopped")
        self.instances_var = tk.StringVar(value="0")
        self.players_var = tk.StringVar(value="0")
        self.relay_status_var = tk.StringVar(value="Not tested")
        self.count_var = tk.StringVar(value="")

        rows = [
            ("VRChat Logs:", self.watcher_status_var),
            ("Active VRChat Instances:", self.instances_var),
            ("Tracked Players:", self.players_var),
            ("Relay:", self.relay_status_var),
            ("Session / Queue:", self.count_var),
        ]
        for row, (label, variable) in enumerate(rows):
            ttk.Label(status_frame, text=label).grid(
                row=row,
                column=0,
                sticky=tk.W,
                padx=6,
                pady=3,
            )
            ttk.Label(status_frame, textvariable=variable).grid(
                row=row,
                column=1,
                sticky=tk.W,
                padx=6,
                pady=3,
            )

        action_frame = ttk.Frame(container)
        action_frame.pack(fill=tk.X, pady=(0, 10))
        self.start_btn = ttk.Button(
            action_frame,
            text="Start Node",
            command=self.start_node,
        )
        self.start_btn.pack(side=tk.LEFT, padx=(0, 6))
        self.stop_btn = ttk.Button(
            action_frame,
            text="Stop Node",
            command=self.stop_node,
            state=tk.DISABLED,
        )
        self.stop_btn.pack(side=tk.LEFT, padx=6)
        self.diagnostic_btn = ttk.Button(action_frame, text="Diagnose Tracking", command=self.diagnose_tracking)
        self.diagnostic_btn.pack(side=tk.LEFT, padx=6)

        recent_frame = ttk.LabelFrame(container, text="Recent Node Activity")
        recent_frame.pack(fill=tk.BOTH, expand=True)
        self.recent_text = tk.Text(
            recent_frame,
            height=10,
            wrap=tk.WORD,
            state=tk.DISABLED,
            bg="#2d2d2d",
            fg="#ffffff",
        )
        self.recent_text.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)

        self._schedule_refresh()

    def diagnose_tracking(self):
        """Run the built-in privacy-safe diagnostic in the background."""
        self.diagnostic_btn.config(state=tk.DISABLED)
        self._activity("Tracking diagnostic started (10-second sample)")
        snapshot = self.watcher.snapshot()
        _total, pending, _submitted = self.store.counts()
        stats = dict(seen=self.session_seen, new=self.session_new,
                     duplicates=self.session_duplicates, pending=pending)

        def worker():
            try:
                report, diagnosis = run_tracking_diagnostic(
                    log_dir=self.watcher.log_dir,
                    output_dir=os.path.join(os.path.expanduser("~"), "Downloads"),
                    sample_seconds=10, watcher_snapshot=snapshot, session_stats=stats)
            except Exception as error:
                error_type = type(error).__name__
                def failed():
                    self.diagnostic_btn.config(state=tk.NORMAL)
                    self._activity("Tracking diagnostic failed")
                    messagebox.showerror("Tracking Diagnostic",
                                         f"Could not generate report: {error_type}")
                self._ui(failed)
                return

            def completed():
                self.diagnostic_btn.config(state=tk.NORMAL)
                self._activity("Tracking diagnostic complete — report saved")
                if messagebox.askyesno(
                    "Tracking Diagnostic",
                    f"{diagnosis}\n\nReport saved to:\n{report}\n\nOpen report now?"
                ):
                    try:
                        os.startfile(report)
                    except (AttributeError, OSError):
                        pass
            self._ui(completed)

        threading.Thread(target=worker, daemon=True,
                         name="PluginNodeTrackingDiagnostic").start()

    def _ui(self, function, *args, **kwargs):
        try:
            if self.app and self.app.root and not self.shutting_down:
                self.app.root.after(0, lambda: function(*args, **kwargs))
        except Exception:
            pass

    def _log(self, message):
        try:
            if self.app and self.app.logic:
                self.app.logic.log(message)
        except Exception:
            pass

    def _activity(self, message):
        self.recent_messages.put(
            f"[{datetime.now().strftime('%H:%M:%S')}] {message}"
        )

    def _schedule_refresh(self):
        if self.shutting_down or not self.app or not getattr(self.app, "root", None):
            return
        self._refresh_ui()
        try:
            self.refresh_job = self.app.root.after(500, self._schedule_refresh)
        except Exception:
            self.refresh_job = None

    def _refresh_ui(self):
        if self.tab is None or self.shutting_down:
            return
        _total, pending, _submitted = self.store.counts()
        self.count_var.set(
            f"Seen {self.session_seen} | New {self.session_new} | "
            f"Local duplicates {self.session_duplicates} | "
            f"Uploaded {self.session_submitted} | Waiting {pending}"
        )
        while True:
            try:
                message = self.recent_messages.get_nowait()
            except queue.Empty:
                break
            self.recent_text.config(state=tk.NORMAL)
            self.recent_text.insert(tk.END, message + "\n")
            self.recent_text.see(tk.END)
            self.recent_text.config(state=tk.DISABLED)

    def _on_watcher_status(self, summary):
        if isinstance(summary, dict):
            active = bool(summary.get("logging_warning"))
            if active != getattr(self, "_last_logging_warning", False):
                self._last_logging_warning = active
                self._activity('WARNING: VRChat logging appears disabled (no recent log data). Enable VRChat output logging in VRChat settings and restart VRChat.' if active else
                                 "VRChat logging resumed; warning cleared.")
        if not isinstance(summary, dict):
            self._ui(self.watcher_status_var.set, str(summary))
            return
        self._ui(
            self.watcher_status_var.set,
            summary.get("message", "Watching VRChat logs"),
        )
        self._ui(self.instances_var.set, str(summary.get("active_logs", 0)))
        self._ui(self.players_var.set, str(summary.get("active_players", 0)))

    def _save_from_ui(self, silent=False):
        if self.tab is None:
            return
        self.settings.update(
            {
                # node_name is relay-owned. Keep only the last canonical name
                # returned by Apps Script; never overwrite it from local UI.
                "sync_interval_seconds": max(15, int(self.sync_interval_var.get())),
                "batch_size": max(1, min(250, int(self.batch_size_var.get()))),
                "local_dedupe_minutes": max(0, int(self.dedupe_var.get())),
                "auto_start": bool(self.auto_start_var.get()),
            }
        )
        self._save_settings()
        if not silent:
            messagebox.showinfo("TGC Invite Node", "Node configuration saved.")

    def save_from_ui(self):
        try:
            self._save_from_ui(silent=False)
        except Exception as error:
            messagebox.showerror("TGC Invite Node", f"Could not save settings: {error}")

    # ------------------------------------------------------------------
    # Sighting collection
    # ------------------------------------------------------------------
    def _on_join(self, user_id, display_name, seen_at, source_log=None):
        self.session_seen += 1
        ignored = set(self.settings.get("ignore_user_ids") or [])
        if user_id in ignored:
            return

        added, _event_id = self.store.add_sighting(
            user_id,
            display_name,
            seen_at,
            int(self.settings.get("local_dedupe_minutes", 60)),
        )
        if added:
            self.session_new += 1
            source = os.path.basename(source_log) if source_log else "VRChat"
            self._activity(f"Queued: {display_name} ({user_id}) — {source}")
        else:
            self.session_duplicates += 1
            self._activity(f"Local duplicate: {display_name}")

    # ------------------------------------------------------------------
    # Relay client
    # ------------------------------------------------------------------
    def _post_to_url(self, url, payload, timeout=25):
        url = str(url or "").strip()
        if not url.lower().startswith("https://"):
            raise RuntimeError("Apps Script Web App URL is missing or invalid.")
        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "User-Agent": f"TGC-Invite-Node/{NODE_VERSION}",
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8", errors="replace"))
        if not isinstance(data, dict) or not data.get("ok"):
            raise RuntimeError(
                (data.get("error") if isinstance(data, dict) else "")
                or "Relay rejected request."
            )
        return data

    def _parse_deployment_input(self, value):
        import re as _re
        value = str(value or "").strip()
        if not value:
            raise RuntimeError("Paste the deployment link or code from a TGC owner.")
        relay_url = str(self.settings.get("relay_url") or "").strip()
        code = value.upper()
        if value.lower().startswith("https://"):
            parsed = urllib.parse.urlsplit(value)
            query = urllib.parse.parse_qs(parsed.query)
            code = str((query.get("deploy") or [""])[0]).strip().upper()
            relay_url = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, "", ""))
        if not _re.fullmatch(r"TGC-DEPLOY(?:-[A-F0-9]{4}){5}", code):
            raise RuntimeError("That is not a valid TGC deployment code/link.")
        if not relay_url.lower().startswith("https://"):
            raise RuntimeError("This fresh install needs the full deployment link, not only the short code.")
        return relay_url, code

    def redeem_deployment(self):
        try:
            relay_url, code = self._parse_deployment_input(self.deploy_var.get())
        except Exception as error:
            messagebox.showerror("Deploy TGC Invite Node", str(error))
            return
        install_id = str(self.settings.get("install_id") or "").strip() or uuid.uuid4().hex
        self.settings["install_id"] = install_id
        try:
            self._save_settings()
        except Exception:
            pass
        self.relay_status_var.set("Redeeming one-time deployment code…")

        def worker():
            try:
                data = self._post_to_url(
                    relay_url,
                    {
                        "action": "redeem_deployment",
                        "code": code,
                        "client_type": CLIENT_TYPE,
                        "version": NODE_VERSION,
                        "install_id": install_id,
                    },
                    timeout=30,
                )
                node_id = str(data.get("node_id") or "").strip()
                node_key = str(data.get("node_key") or "").strip()
                node_name = str(data.get("node_name") or "").strip()
                discord_id = str(data.get("discord_id") or "").strip()
                if not node_id or not node_key:
                    raise RuntimeError("Relay did not return complete node credentials.")
                self.settings.update({
                    "relay_url": relay_url,
                    "node_id": node_id,
                    "node_key_runtime": node_key,
                    "node_name": node_name,
                    "auto_start": True,
                })
                self._save_settings()

                def finish():
                    self.relay_url_var.set(relay_url)
                    self.node_id_var.set(node_id)
                    self.node_key_var.set(node_key)
                    self.node_name_var.set(node_name)
                    self.auto_start_var.set(True)
                    self.deploy_var.set("")
                    self.relay_status_var.set(f"Deployed and verified — {node_name or node_id}")
                    messagebox.showinfo(
                        "TGC Invite Node Deployed",
                        "Deployment complete.\n\n"
                        f"Node: {node_name or node_id}\n"
                        + (f"Staff Discord ID: {discord_id}\n" if discord_id else "")
                        + "\nThe Node Key has been saved using Auto Invite's encrypted configuration storage. The node will now start automatically.",
                    )
                    self.start_node()
                    self.check_for_updates(silent=True)
                self._ui(finish)
            except Exception as error:
                self._ui(self.relay_status_var.set, f"Deployment failed: {error}")
                self._ui(messagebox.showerror, "Deploy TGC Invite Node", str(error))

        threading.Thread(target=worker, daemon=True, name="InviteNodeDeployment").start()

    def _post(self, payload, timeout=25):
        url = str(self.settings.get("relay_url") or "").strip()
        if not url:
            raise RuntimeError("Apps Script Web App URL is not configured.")
        return self._post_to_url(url, payload, timeout=timeout)

    def _auth_payload(self, action, **extra):
        node_id = str(self.settings.get("node_id") or "").strip()
        node_key = str(self.settings.get("node_key_runtime") or "").strip()
        if not node_id or not node_key:
            raise RuntimeError("Node ID / Node Key are not configured.")
        # Apps Script / the Nodes sheet is authoritative for the node's
        # display name. Do not send a local node_name back to the relay or a
        # client could overwrite the centrally assigned name.
        payload = {
            "action": action,
            "node_id": node_id,
            "node_key": node_key,
            "version": NODE_VERSION,
            "client_type": CLIENT_TYPE,
        }
        payload.update(extra)
        return payload

    def _apply_relay_identity(self, data):
        """Cache and display the canonical node name returned by Apps Script."""
        canonical_name = str((data or {}).get("node_name") or "").strip()
        if not canonical_name:
            return

        self.settings["node_name"] = canonical_name
        try:
            self._save_settings()
        except Exception as error:
            self._log(f"Invite Node: could not cache relay node name: {error}")

        if hasattr(self, "node_name_var"):
            self._ui(self.node_name_var.set, canonical_name)

    def _refresh_relay_identity(self, update_status=True):
        """Authenticate with the relay and refresh the centrally assigned name."""
        try:
            data = self._post(self._auth_payload("node_status"))
            self._apply_relay_identity(data)
            canonical_name = str(data.get("node_name") or "").strip()
            if update_status:
                label = canonical_name or str(self.settings.get("node_id") or "")
                self._ui(self.relay_status_var.set, f"Connected — {label}")
            return data
        except Exception as error:
            if update_status:
                self._ui(self.relay_status_var.set, f"Error: {error}")
            self._activity(f"Relay test failed: {error}")
            self._log(f"Invite Node: relay authentication failed: {error}")
            return None

    @staticmethod
    def _version_tuple(value):
        text = str(value or "").strip().lower().replace("-plugin", "")
        import re as _re
        match = _re.search(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?", text)
        if not match:
            return (0, 0, 0)
        return tuple(int(part or 0) for part in match.groups())

    def _fetch_github_release(self):
        request = urllib.request.Request(
            UPDATE_MANIFEST_URL,
            headers={
                "Accept": "application/json",
                "Cache-Control": "no-cache",
                "User-Agent": f"TGC-Invite-Node-Updater/{NODE_VERSION}",
            },
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            raw = response.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise RuntimeError("GitHub update manifest returned invalid JSON.")
        releases = data.get("releases") or {}
        release = releases.get(CLIENT_TYPE) if isinstance(releases, dict) else None
        if not isinstance(release, dict):
            raise RuntimeError("GitHub update manifest has no plugin release entry.")
        return release

    def _release_available(self, info):
        if not isinstance(info, dict):
            return False
        version = str(info.get("version") or "").strip()
        if not version:
            return False
        remote = self._version_tuple(version)
        installed = self._version_tuple(NODE_VERSION)
        if remote != installed:
            return remote > installed
        try:
            return int(info.get("hotfix_revision") or 0) > HOTFIX_REVISION
        except (TypeError, ValueError):
            return False

    def _apply_release_info(self, release):
        if not isinstance(release, dict):
            return
        channel = str(release.get("channel") or CLIENT_TYPE).strip().lower()
        if channel and channel != CLIENT_TYPE:
            return
        version = str(release.get("version") or "").strip()
        if not version:
            return
        info = dict(release)
        info["version"] = version
        info["policy"] = str(info.get("policy") or "optional").strip().lower()
        self.release_info = info
        available = self._release_available(info)
        self.update_required = available and info["policy"] == "required"

        def apply_ui():
            if available:
                policy = info["policy"].capitalize()
                text = f"Update available: {version} — {policy}"
                notes = str(info.get("notes") or "").strip()
                if notes:
                    text += f" — {notes}"
                self.update_status_var.set(text)
                self.install_update_btn.config(state=tk.NORMAL if not self.update_in_progress else tk.DISABLED)
                update_id = f"{version}:hotfix{info.get('hotfix_revision', 0)}"
                if info["policy"] in {"recommended", "required"} and self.update_notice_shown_for != update_id:
                    self.update_notice_shown_for = update_id
                    detail = f"TGC Invite Node plugin {version} is {info['policy']}.\n\n"
                    if notes:
                        detail += notes + "\n\n"
                    if info["policy"] == "required":
                        detail += "Sightings will continue buffering locally, but relay uploads are paused until you update and restart Auto Invite."
                    else:
                        detail += "Please install the update when practical."
                    messagebox.showwarning("TGC Invite Node Update", detail)
            else:
                self.update_status_var.set(f"Installed: {NODE_VERSION} — current")
                self.install_update_btn.config(state=tk.DISABLED)
        self._ui(apply_ui)

    def check_for_updates(self, silent=False):
        try:
            self._save_from_ui(silent=True)
        except Exception as error:
            if not silent:
                messagebox.showerror("TGC Invite Node", str(error))
            return

        def worker():
            try:
                release = self._fetch_github_release()
                self._apply_release_info(release)
                if not silent and not self._release_available(release):
                    self._ui(messagebox.showinfo, "TGC Invite Node", f"This plugin node is current ({NODE_VERSION}).")
            except Exception as error:
                self._ui(self.update_status_var.set, f"GitHub update check failed: {error}")
                if not silent:
                    self._ui(messagebox.showerror, "TGC Invite Node", f"Could not check GitHub for updates:\n\n{error}")

        threading.Thread(target=worker, daemon=True, name="InviteNodePluginUpdateCheck").start()

    @staticmethod
    def _safe_zip_members(zf):
        members = []
        for info in zf.infolist():
            name = info.filename.replace("\\", "/")
            if not name or name.endswith("/"):
                continue
            if name.startswith("/") or ".." in name.split("/"):
                raise RuntimeError(f"Unsafe path in update package: {name}")
            members.append((info, name))
        return members

    def _download_plugin_update(self, info):
        version = str(info.get("version") or "").strip()
        url = str(info.get("url") or "").strip()
        expected_hash = str(info.get("sha256") or "").strip().lower()
        if not version or not url or not expected_hash:
            raise RuntimeError("The GitHub release metadata is incomplete.")
        if not url.lower().startswith("https://"):
            raise RuntimeError("Update downloads must use HTTPS.")
        import re as _re
        if not _re.fullmatch(r"[0-9a-f]{64}", expected_hash):
            raise RuntimeError("The GitHub release SHA-256 is invalid.")

        updates_dir = os.path.join(self.root_dir, "invite_node_updates")
        os.makedirs(updates_dir, exist_ok=True)
        temp_zip = os.path.join(updates_dir, f"plugin_update_{version}.zip.part")
        digest = hashlib.sha256()
        downloaded = 0
        req = urllib.request.Request(url, headers={"User-Agent": f"TGC-Invite-Node-Updater/{NODE_VERSION}"})
        with urllib.request.urlopen(req, timeout=60) as response, open(temp_zip, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                downloaded += len(chunk)
                if downloaded > MAX_UPDATE_DOWNLOAD_BYTES:
                    raise RuntimeError("Update package is unexpectedly large.")
                digest.update(chunk)
                output.write(chunk)
        actual_hash = digest.hexdigest().lower()
        if actual_hash != expected_hash:
            try:
                os.remove(temp_zip)
            except OSError:
                pass
            raise RuntimeError("Update checksum verification failed. The package was not installed.")

        staging = tempfile.mkdtemp(prefix="tgc_plugin_update_", dir=updates_dir)
        wanted = {"plugins/distributed_invite_node.py", "tgc_vrchat_multilog.py", "tgc_node_diagnostics.py"}
        found = set()
        with zipfile.ZipFile(temp_zip, "r") as zf:
            members = self._safe_zip_members(zf)
            names = [name for _, name in members]
            # Handoff packs may wrap the runtime files in one top-level folder.
            prefix = ""
            if not wanted.issubset(set(names)):
                prefixes = {name.split("/", 1)[0] for name in names if "/" in name}
                for candidate in prefixes:
                    cand = candidate + "/"
                    if all(cand + rel in names for rel in wanted):
                        prefix = cand
                        break
            for info_obj, name in members:
                rel = name[len(prefix):] if prefix and name.startswith(prefix) else name
                if rel not in wanted:
                    continue
                dst = os.path.join(staging, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with zf.open(info_obj) as src, open(dst, "wb") as out:
                    shutil.copyfileobj(src, out)
                found.add(rel)
        try:
            os.remove(temp_zip)
        except OSError:
            pass
        if found != wanted:
            shutil.rmtree(staging, ignore_errors=True)
            raise RuntimeError("Update ZIP does not contain all plugin runtime files.")
        return staging

    def install_update(self):
        info = dict(self.release_info or {})
        version = str(info.get("version") or "").strip()
        if not self._release_available(info):
            messagebox.showinfo("TGC Invite Node", "No newer plugin update is currently available.")
            return
        policy = str(info.get("policy") or "optional").capitalize()
        notes = str(info.get("notes") or "").strip()
        prompt = f"Install Invite Node plugin {version}?\n\nPolicy: {policy}"
        if notes:
            prompt += f"\n\n{notes}"
        prompt += "\n\nThe plugin files will be backed up and replaced. Your encrypted Node Key, settings, queue database, and the rest of Auto Invite are preserved. Restart Auto Invite after installation to load the new plugin code."
        if not messagebox.askyesno("Install Plugin Update", prompt):
            return
        if self.update_in_progress:
            return
        self.update_in_progress = True
        self.install_update_btn.config(state=tk.DISABLED)
        self.update_status_var.set(f"Downloading {version}…")

        def worker():
            staging = None
            try:
                staging = self._download_plugin_update(info)
                updates_dir = os.path.join(self.root_dir, "invite_node_updates")
                stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup = os.path.join(updates_dir, "backups", stamp)
                os.makedirs(os.path.join(backup, "plugins"), exist_ok=True)
                targets = [
                    ("plugins/distributed_invite_node.py", os.path.join(self.root_dir, "plugins", "distributed_invite_node.py")),
                    ("tgc_vrchat_multilog.py", os.path.join(self.root_dir, "tgc_vrchat_multilog.py")),
                ]
                replaced = []
                try:
                    for rel, target in targets:
                        source = os.path.join(staging, rel)
                        if os.path.exists(target):
                            backup_target = os.path.join(backup, rel)
                            os.makedirs(os.path.dirname(backup_target), exist_ok=True)
                            shutil.copy2(target, backup_target)
                        temp_target = target + ".update_tmp"
                        shutil.copy2(source, temp_target)
                        os.replace(temp_target, target)
                        replaced.append((rel, target))
                except Exception:
                    for rel, target in reversed(replaced):
                        old = os.path.join(backup, rel)
                        if os.path.exists(old):
                            shutil.copy2(old, target)
                    raise
                self._ui(self.update_status_var.set, f"Installed {version} — restart Auto Invite to activate")
                self._activity(f"Plugin update {version} installed; restart Auto Invite to activate it")
                self._ui(messagebox.showinfo, "Plugin Update Installed", f"Invite Node plugin {version} was installed successfully.\n\nRestart the Auto Invite application to load the new plugin.\n\nYour Node credentials and queue were preserved.")
            except Exception as error:
                self._ui(self.update_status_var.set, f"Update failed: {error}")
                self._ui(messagebox.showerror, "Plugin Update Failed", str(error))
            finally:
                self.update_in_progress = False
                if staging:
                    shutil.rmtree(staging, ignore_errors=True)

        threading.Thread(target=worker, daemon=True, name="InviteNodePluginUpdater").start()

    def test_relay(self):
        try:
            self._save_from_ui(silent=True)
        except Exception as error:
            self.relay_status_var.set(f"Settings error: {error}")
            return

        def worker():
            data = self._refresh_relay_identity(update_status=True)
            if data is not None:
                self._activity("Relay authentication test succeeded")
                self._log("Invite Node: relay authentication test succeeded")

        threading.Thread(
            target=worker,
            daemon=True,
            name="TGC-InviteNode-TestRelay",
        ).start()

    def generate_discord_link_code(self):
        """Request a one-time relay code that can be claimed with /verifynode."""
        try:
            self._save_from_ui(silent=True)
        except Exception as error:
            self.relay_status_var.set(f"Settings error: {error}")
            return

        def worker():
            try:
                data = self._post(
                    self._auth_payload("create_node_link_code")
                )
                self._apply_relay_identity(data)
                code = str(data.get("code") or "").strip()
                expires_at = str(data.get("expires_at") or "").strip()
                node_name = str(
                    data.get("node_name")
                    or self.settings.get("node_name")
                    or "this node"
                )
                if not code:
                    raise RuntimeError(
                        "Relay did not return a Discord link code"
                    )

                def show_code():
                    try:
                        self.app.root.clipboard_clear()
                        self.app.root.clipboard_append(code)
                        self.app.root.update_idletasks()
                    except Exception:
                        pass

                    self.relay_status_var.set(
                        f"Discord link code ready — {code}"
                    )
                    messagebox.showinfo(
                        "Link Node to Discord",
                        (
                            f"Node: {node_name}\n\n"
                            f"Your one-time Discord link code is:\n\n{code}\n\n"
                            "The code has been copied to your clipboard.\n"
                            "In the TGC Discord, run:\n"
                            f"/verifynode code:{code}\n\n"
                            "This code expires in 10 minutes and can only be used once."
                            + (
                                f"\nExpires: {expires_at}"
                                if expires_at
                                else ""
                            )
                        ),
                    )
                    self._activity(
                        f"Generated Discord link code for {node_name}"
                    )

                self._ui(show_code)
            except Exception as error:
                self._ui(
                    self.relay_status_var.set,
                    f"Link error: {error}",
                )
                self._ui(
                    messagebox.showerror,
                    "Link Node to Discord",
                    str(error),
                )
                self._activity(f"Discord link-code request failed: {error}")
                self._log(
                    f"Invite Node: Discord link-code request failed: {error}"
                )

        threading.Thread(
            target=worker,
            daemon=True,
            name="TGC-InviteNode-DiscordLinkCode",
        ).start()

    def sync_now(self):
        try:
            self._save_from_ui(silent=True)
        except Exception as error:
            self.relay_status_var.set(f"Settings error: {error}")
            return
        threading.Thread(
            target=self._sync_once,
            daemon=True,
            name="TGC-InviteNode-SyncNow",
        ).start()

    def _sync_once(self):
        if self.update_required:
            self._ui(self.relay_status_var.set, "Required plugin update — sightings are buffered locally")
            return 0
        if not self.sync_lock.acquire(blocking=False):
            return 0
        try:
            # Allow the collector to operate without relay configuration. This is
            # useful during setup and guarantees sightings remain buffered locally.
            if not str(self.settings.get("relay_url") or "").strip():
                self._ui(
                    self.relay_status_var.set,
                    "Not configured — buffering locally",
                )
                return 0
            if not str(self.settings.get("node_id") or "").strip() or not str(
                self.settings.get("node_key_runtime") or ""
            ).strip():
                self._ui(
                    self.relay_status_var.set,
                    "Node credentials missing — buffering locally",
                )
                return 0

            batch = self.store.pending(
                int(self.settings.get("batch_size", 100))
            )
            if not batch:
                self._ui(
                    self.relay_status_var.set,
                    "Connected — nothing queued",
                )
                return 0

            sightings = [
                {
                    "event_id": row["event_id"],
                    "user_id": row["user_id"],
                    "display_name": row.get("display_name") or row["user_id"],
                    "seen_at": row["seen_at"],
                }
                for row in batch
            ]
            event_ids = [row["event_id"] for row in batch]

            try:
                result = self._post(
                    self._auth_payload(
                        "submit_sightings",
                        sightings=sightings,
                    )
                )
                self._apply_relay_identity(result)
                accepted = list(result.get("accepted_event_ids") or [])
                self.store.mark_submitted(accepted)
                self.session_submitted += len(accepted)
                rejected = list(result.get("rejected_event_ids") or [])
                if rejected:
                    self.store.mark_attempt_error(
                        rejected,
                        "Relay rejected this sighting payload",
                    )
                self._ui(
                    self.relay_status_var.set,
                    f"Connected — submitted {len(accepted)}",
                )
                if accepted:
                    self._activity(
                        f"Uploaded {len(accepted)} sighting(s) to central relay"
                    )
                return len(accepted)
            except Exception as error:
                self.store.mark_attempt_error(event_ids, error)
                self._ui(
                    self.relay_status_var.set,
                    f"Offline / retrying later: {error}",
                )
                self._log(f"Invite Node: relay sync failed: {error}")
                return 0
        finally:
            self.sync_lock.release()

    def _sync_worker(self):
        while not self.sync_stop.is_set():
            self._sync_once()
            interval = max(
                15,
                int(self.settings.get("sync_interval_seconds", 60)),
            )
            if self.sync_stop.wait(interval):
                break

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def start_node(self):
        if self.shutting_down:
            return
        try:
            self._save_from_ui(silent=True)
        except Exception as error:
            messagebox.showerror("TGC Invite Node", f"Could not save settings: {error}")
            return

        # Refresh the relay-owned display name without blocking node startup.
        # Collection can continue offline if Google is temporarily unavailable.
        threading.Thread(
            target=self._refresh_relay_identity,
            kwargs={"update_status": True},
            daemon=True,
            name="TGC-InviteNode-RefreshIdentity",
        ).start()

        watcher_started = self.watcher.start()
        if not self.sync_thread or not self.sync_thread.is_alive():
            self.sync_stop.clear()
            self.sync_thread = threading.Thread(
                target=self._sync_worker,
                daemon=True,
                name="TGC-InviteNode-Sync",
            )
            self.sync_thread.start()

        if self.start_btn is not None:
            self.start_btn.config(state=tk.DISABLED)
        if self.stop_btn is not None:
            self.stop_btn.config(state=tk.NORMAL)
        if watcher_started:
            self._activity("Node started")
            self._log("Invite Node: started multi-instance VRChat log collector")

    def stop_node(self):
        try:
            self.watcher.stop()
        except Exception:
            pass
        self.sync_stop.set()
        thread = self.sync_thread
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=1.5)
        if self.start_btn is not None:
            try:
                self.start_btn.config(state=tk.NORMAL)
            except Exception:
                pass
        if self.stop_btn is not None:
            try:
                self.stop_btn.config(state=tk.DISABLED)
            except Exception:
                pass
        if hasattr(self, "watcher_status_var"):
            self._ui(self.watcher_status_var.set, "Stopped")
            self._ui(self.instances_var.set, "0")
            self._ui(self.players_var.set, "0")
        if not self.shutting_down:
            self._activity("Node stopped")
            self._log("Invite Node: stopped")
